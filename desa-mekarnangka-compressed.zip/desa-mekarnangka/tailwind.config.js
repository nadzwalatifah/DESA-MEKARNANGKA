import defaultTheme from 'tailwindcss/defaultTheme';
import forms from '@tailwindcss/forms';

/** @type {import('tailwindcss').Config} */
export default {
    content: [
        './vendor/laravel/framework/src/Illuminate/Pagination/resources/views/*.blade.php',
        './storage/framework/views/*.php',
        './resources/views/**/*.blade.php',
    ],

    theme: {
        extend: {
            colors: {
                'desa-teal-dark': '#0f3d3b',
                'desa-teal': '#1f6f63',
                'desa-tosca': '#4fae9b',
                'desa-gold': '#c9962f',
                'desa-gold-soft': '#e6c878',
                'desa-cream': '#f4efe1',
                'desa-bg': '#faf8f2',
                'desa-ink': '#1c2b27',
                'desa-line': '#e7e0cd',
            },
            fontFamily: {
                sans: ['"Plus Jakarta Sans"', ...defaultTheme.fontFamily.sans],
                serif: ['Fraunces', 'ui-serif', 'Georgia', 'serif'],
            },
        },
    },

    plugins: [forms],
};
