@extends('layouts.app')

@section('content')

    {{-- HERO --}}
    <section class="relative text-white overflow-hidden min-h-[78vh] flex items-center">
        <div class="absolute inset-0 bg-cover bg-center" style="background-image: url('{{ asset('storage/hero.jpg') }}');"></div>
        <div class="absolute inset-0" style="background: linear-gradient(180deg, rgba(15,61,59,.55) 0%, rgba(15,61,59,.72) 55%, rgba(15,61,59,.92) 100%);"></div>
        <div class="relative z-10 max-w-4xl mx-auto px-4 py-20 text-center w-full">
            <span class="inline-flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-desa-gold-soft mb-5">
                <span class="w-6 h-px bg-desa-gold-soft"></span>
                Website Resmi Pemerintah Desa
                <span class="w-6 h-px bg-desa-gold-soft"></span>
            </span>
            <h1 class="font-display text-4xl md:text-6xl font-semibold leading-[1.08]">Selamat Datang di {{ $setting->nama_desa ?? 'Desa Mekarnangka' }}</h1>
            @if($setting->deskripsi_singkat ?? false)
                <p class="mt-4 text-base md:text-lg text-white/85 max-w-2xl mx-auto leading-relaxed">{{ $setting->deskripsi_singkat }}</p>
            @endif

            <p class="mt-4 text-sm md:text-base text-white/75 flex items-center justify-center gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4 text-desa-gold-soft" viewBox="0 0 20 20" fill="currentColor">
                    <path fill-rule="evenodd" d="M9.69 18.933l.003.001C9.89 19.02 10 19 10 19s.11.02.308-.066l.002-.001.006-.003.018-.008a5.741 5.741 0 00.281-.14c.186-.096.446-.24.757-.433.62-.384 1.445-.966 2.274-1.765C15.302 14.988 17 12.493 17 9A7 7 0 103 9c0 3.492 1.698 5.988 3.355 7.584a13.731 13.731 0 002.273 1.765 11.842 11.842 0 00.976.544l.062.029.018.008.006.003zM10 11.25a2.25 2.25 0 100-4.5 2.25 2.25 0 000 4.5z" clip-rule="evenodd" />
                </svg>
                Kecamatan {{ $setting->kecamatan ?? '...' }}, Kabupaten {{ $setting->kabupaten ?? '...' }}
            </p>

            <div class="mt-8 flex flex-wrap items-center justify-center gap-3">
                <a href="#profil-desa" class="px-6 py-3 bg-desa-gold hover:bg-desa-gold-soft text-desa-teal-dark text-sm font-semibold rounded-lg transition shadow-lg shadow-black/10">
                    Lihat Profil Desa
                </a>
                <a href="{{ route('kontak') }}" class="px-6 py-3 bg-white/10 hover:bg-white/20 border border-white/30 text-white text-sm font-semibold rounded-lg backdrop-blur-sm transition">
                    Hubungi Kami
                </a>
            </div>
        </div>

        <div class="absolute bottom-0 inset-x-0 h-10 bg-gradient-to-t from-desa-bg to-transparent"></div>
    </section>

    {{-- SAMBUTAN KEPALA DESA --}}
    @if($setting->sambutan_kepala_desa || $setting->foto_kepala_desa || $setting->nama_kepala_desa || $setting->video_kepala_desa)
    <section id="sambutanSection" class="max-w-6xl mx-auto px-4 -mt-16 relative z-10">
        <div class="bg-white border border-desa-line shadow-xl shadow-black/5 rounded-2xl p-6 md:p-10 overflow-hidden">
            <div id="sambutanGrid" class="sambutan-grid">

                <div id="profileBlock" class="flex items-center gap-3">
                    <div class="w-12 h-12 rounded-full flex items-center justify-center text-white font-display font-semibold text-sm overflow-hidden shrink-0 ring-2 ring-desa-gold-soft" style="background: linear-gradient(135deg, #1f6f63, #0f3d3b);">
                        @if($setting->foto_kepala_desa)
                            <img src="{{ asset('storage/'.$setting->foto_kepala_desa) }}" class="w-full h-full object-cover">
                        @else
                            {{ collect(explode(' ', $setting->nama_kepala_desa ?? ''))->map(fn($w) => strtoupper(substr($w,0,1)))->take(2)->implode('') }}
                        @endif
                    </div>
                    <div>
                        <span class="block text-[11px] font-semibold uppercase tracking-[0.14em] text-desa-teal">Sambutan Resmi</span>
                        <p class="font-display font-semibold text-desa-ink leading-tight mt-1">{{ $setting->nama_kepala_desa }}</p>
                        <p class="text-sm text-desa-ink/50 leading-tight">Kepala Desa</p>
                    </div>
                </div>

                @if($setting->video_kepala_desa)
                <div id="videoBlock" class="rounded-xl overflow-hidden aspect-video border border-desa-line">
                    <video src="{{ asset('storage/'.$setting->video_kepala_desa) }}" controls class="w-full h-full object-cover"></video>
                </div>
                @endif

                @if($setting->sambutan_kepala_desa)
                <div id="textBlock">
                    <div id="textWrap" class="relative">
                        <p id="sambutanText" class="text-desa-ink/70 leading-relaxed whitespace-pre-line overflow-hidden" style="max-height: 6.5em; transition: max-height 450ms cubic-bezier(0.4, 0, 0.2, 1);">{{ $setting->sambutan_kepala_desa }}</p>
                        <div id="textFade" class="absolute inset-x-0 bottom-0 h-16 bg-gradient-to-t from-white via-white/80 to-transparent pointer-events-none" style="transition: opacity 450ms cubic-bezier(0.4, 0, 0.2, 1);"></div>
                    </div>
                    <button id="sambutanToggle" onclick="toggleSambutan()" class="mt-4 px-4 py-2 text-sm font-medium text-desa-teal-dark border border-desa-line rounded-lg hover:bg-desa-bg transition">Baca selengkapnya</button>
                </div>
                @endif

            </div>
        </div>
    </section>
    @endif

    <style>
        .sambutan-grid {
            display: grid;
            grid-template-columns: 1fr;
            grid-template-areas: "profile" "video" "text";
            gap: 1.5rem;
        }
        @media (min-width: 640px) {
            .sambutan-grid {
                grid-template-columns: 1fr 1fr;
                grid-template-areas: "profile video" "text video";
                gap: 2.5rem;
                align-items: center;
            }
            .sambutan-grid.expanded {
                grid-template-columns: 1fr 16rem;
                grid-template-areas: "profile video" "text text";
                align-items: center;
            }
            .sambutan-grid.expanded #profileBlock {
                transform: scale(1.15);
                transform-origin: left center;
            }
        }
        #profileBlock { grid-area: profile; transition: transform 450ms cubic-bezier(0.4, 0, 0.2, 1); }
        #videoBlock { grid-area: video; align-self: center; }
        #textBlock { grid-area: text; }
        .sambutan-grid.expanded #textBlock {
            margin-top: 0.5rem;
            padding-top: 1.5rem;
            border-top: 1px solid var(--tw-border-opacity, #e5e7eb);
        }
    </style>

    <script>
        function toggleSambutan() {
            const grid = document.getElementById('sambutanGrid');
            const video = document.getElementById('videoBlock');
            const text = document.getElementById('sambutanText');
            const fade = document.getElementById('textFade');
            const btn = document.getElementById('sambutanToggle');
            const willExpand = !grid.classList.contains('expanded');
            const isDesktop = window.matchMedia('(min-width: 640px)').matches;

            // FLIP: catat posisi & ukuran video SEBELUM layout berubah
            const before = (isDesktop && video) ? video.getBoundingClientRect() : null;

            // Semua perubahan state dieksekusi bersamaan, di tick yang sama
            grid.classList.toggle('expanded', willExpand);
            text.style.maxHeight = willExpand ? text.scrollHeight + 'px' : '6.5em';
            if (fade) fade.style.opacity = willExpand ? '0' : '1';
            btn.textContent = willExpand ? 'Tutup' : 'Baca selengkapnya';

            // FLIP: bandingkan posisi baru, lalu animasikan dari posisi lama -> baru
            if (before && video) {
                const after = video.getBoundingClientRect();
                const dx = before.left - after.left;
                const dy = before.top - after.top;
                const sx = before.width / after.width;
                const sy = before.height / after.height;

                video.style.transformOrigin = 'top left';
                video.style.transition = 'none';
                video.style.transform = `translate(${dx}px, ${dy}px) scale(${sx}, ${sy})`;

                requestAnimationFrame(() => {
                    video.style.transition = 'transform 450ms cubic-bezier(0.4, 0, 0.2, 1)';
                    video.style.transform = 'none';
                });

                video.addEventListener('transitionend', function cleanup() {
                    video.style.transition = '';
                    video.style.transform = '';
                    video.removeEventListener('transitionend', cleanup);
                });
            }
        }
    </script>

    {{-- PROFIL DESA --}}
    <section id="profil-desa" class="max-w-6xl mx-auto px-4 py-20 space-y-10 scroll-mt-24 border-t border-desa-line">
        <div>
            <h2 class="font-display text-2xl md:text-3xl font-semibold mb-4">Profil {{ $setting->nama_desa }}</h2>
            <p class="text-desa-ink/70 leading-relaxed max-w-3xl">{{ $setting->sejarah ?? 'Sejarah desa belum diisi.' }}</p>
        </div>

        <div class="grid md:grid-cols-2 gap-6">
            <div class="bg-white rounded-xl border border-desa-line shadow-sm p-6 border-l-4 border-l-desa-gold">
                <h3 class="font-display font-semibold text-lg mb-2 text-desa-teal-dark">Visi</h3>
                <p class="text-desa-ink/70 leading-relaxed">{{ $setting->visi ?? '-' }}</p>
            </div>
            <div class="bg-white rounded-xl border border-desa-line shadow-sm p-6 border-l-4 border-l-desa-gold">
                <h3 class="font-display font-semibold text-lg mb-2 text-desa-teal-dark">Misi</h3>
                <p class="text-desa-ink/70 leading-relaxed whitespace-pre-line">{{ $setting->misi ?? '-' }}</p>
            </div>
        </div>

        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div class="bg-desa-teal-dark/[0.04] border border-desa-line rounded-xl p-5">
                <p class="text-xs text-desa-ink/50 mb-1">Luas Wilayah</p>
                <p class="font-display font-semibold text-lg text-desa-teal-dark">{{ $setting->luas_wilayah_km2 ?? '-' }} km&sup2;</p>
            </div>
            <div class="bg-desa-teal-dark/[0.04] border border-desa-line rounded-xl p-5">
                <p class="text-xs text-desa-ink/50 mb-1">Kecamatan</p>
                <p class="font-display font-semibold text-lg text-desa-teal-dark">{{ $setting->kecamatan ?? '-' }}</p>
            </div>
            <div class="bg-desa-teal-dark/[0.04] border border-desa-line rounded-xl p-5">
                <p class="text-xs text-desa-ink/50 mb-1">Kabupaten</p>
                <p class="font-display font-semibold text-lg text-desa-teal-dark">{{ $setting->kabupaten ?? '-' }}</p>
            </div>
            <div class="bg-desa-teal-dark/[0.04] border border-desa-line rounded-xl p-5">
                <p class="text-xs text-desa-ink/50 mb-1">Provinsi</p>
                <p class="font-display font-semibold text-lg text-desa-teal-dark">{{ $setting->provinsi ?? '-' }}</p>
            </div>
        </div>
    </section>

    {{-- STATISTIK RINGKAS --}}
    @if($statistik)
    <section class="py-16" style="background: linear-gradient(180deg, #0f3d3b, #1f6f63);">
        <div class="max-w-6xl mx-auto px-4">
            <div class="text-center mb-10">
                <span class="text-[11px] font-semibold uppercase tracking-[0.18em] text-desa-gold-soft">Data Kependudukan</span>
                <h2 class="font-display text-2xl md:text-3xl font-semibold text-white mt-2">Statistik Warga {{ $setting->nama_desa }}</h2>
            </div>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6 text-center">
                <div class="bg-white rounded-xl p-6">
                    <p class="font-display text-3xl font-semibold text-desa-teal-dark">{{ $statistik->jumlah_kk }}</p>
                    <p class="text-sm text-desa-ink/50 mt-1">Kepala Keluarga</p>
                </div>
                <div class="bg-white rounded-xl p-6">
                    <p class="font-display text-3xl font-semibold text-desa-teal-dark">{{ $statistik->laki_laki + $statistik->perempuan }}</p>
                    <p class="text-sm text-desa-ink/50 mt-1">Total Penduduk</p>
                </div>
                <div class="bg-white rounded-xl p-6">
                    <p class="font-display text-3xl font-semibold text-desa-teal-dark">{{ $statistik->laki_laki }}</p>
                    <p class="text-sm text-desa-ink/50 mt-1">Laki-laki</p>
                </div>
                <div class="bg-white rounded-xl p-6">
                    <p class="font-display text-3xl font-semibold text-desa-teal-dark">{{ $statistik->perempuan }}</p>
                    <p class="text-sm text-desa-ink/50 mt-1">Perempuan</p>
                </div>
            </div>
        </div>
    </section>
    @endif

    {{-- BERITA TERBARU --}}
    <section class="max-w-6xl mx-auto px-4 py-20 border-t border-desa-line">
        <div class="flex items-center justify-between mb-8">
            <h2 class="font-display text-2xl md:text-3xl font-semibold">Berita Terbaru</h2>
            <a href="{{ route('artikel.index') }}" class="text-desa-teal-dark text-sm font-semibold hover:text-desa-gold transition">Lihat semua &rarr;</a>
        </div>
        <div class="grid md:grid-cols-3 gap-6">
            @forelse($artikelTerbaru as $artikel)
                <a href="{{ route('artikel.show', $artikel) }}" class="group block bg-white rounded-xl border border-desa-line shadow-sm hover:shadow-lg hover:-translate-y-0.5 transition overflow-hidden">
                    <div class="h-44 bg-desa-teal-dark/10 overflow-hidden">
                        @if($artikel->gambar)
                            <img src="{{ asset('storage/'.$artikel->gambar) }}" class="w-full h-full object-cover group-hover:scale-105 transition duration-300">
                        @endif
                    </div>
                    <div class="p-5">
                        <span class="inline-block text-[11px] font-semibold uppercase tracking-wide text-desa-teal-dark bg-desa-teal-dark/[0.06] px-2.5 py-1 rounded-full">{{ $artikel->kategori }}</span>
                        <h3 class="font-display font-semibold mt-3 leading-snug line-clamp-2">{{ $artikel->judul }}</h3>
                        <p class="text-xs text-desa-ink/45 mt-3">{{ $artikel->published_at?->translatedFormat('d F Y') }}</p>
                    </div>
                </a>
            @empty
                <p class="text-desa-ink/40 col-span-full text-center py-10">Belum ada berita.</p>
            @endforelse
        </div>
    </section>

    {{-- GALERI --}}
    <section class="max-w-6xl mx-auto px-4 pb-20 pt-2 border-t border-desa-line">
        <div class="flex items-center justify-between mb-8">
            <h2 class="font-display text-2xl md:text-3xl font-semibold">Galeri Desa</h2>
            <a href="{{ route('galeri.index') }}" class="text-desa-teal-dark text-sm font-semibold hover:text-desa-gold transition">Lihat semua &rarr;</a>
        </div>
        <div class="grid grid-cols-2 md:grid-cols-6 gap-3">
            @forelse($galeri as $foto)
                <div class="aspect-square bg-desa-teal-dark/10 rounded-lg overflow-hidden border border-desa-line">
                    <img src="{{ asset('storage/'.$foto->foto) }}" class="w-full h-full object-cover hover:scale-105 transition duration-300">
                </div>
            @empty
                <p class="text-desa-ink/40 col-span-full text-center py-10">Belum ada foto.</p>
            @endforelse
        </div>
    </section>

@endsection
