@extends('layouts.app')

@section('content')
<div class="max-w-6xl mx-auto px-4 py-16">
    <div class="text-center mb-14">
        <span class="text-[11px] font-semibold uppercase tracking-[0.18em] text-desa-teal">Pemerintahan Desa</span>
        <h1 class="font-display text-3xl md:text-4xl font-semibold mt-2">Struktur Organisasi {{ $setting->nama_desa }}</h1>
    </div>

    @php
        $cocok = fn($kata) => fn($p) => str_contains(strtolower($p->jabatan), $kata);

        $kades  = $pejabat->first($cocok('kepala desa'));
        $sekdes = $pejabat->first($cocok('sekretaris')) ?: $pejabat->first($cocok('sekertaris'));
        $kaur   = $pejabat->filter($cocok('kaur'))->values();
        $kasi   = $pejabat->filter($cocok('kasi'))->values();
        $kadus  = $pejabat->filter(fn($p) => str_contains(strtolower($p->jabatan), 'dusun'))->values();

        $terpakai = collect([$kades->id ?? null, $sekdes->id ?? null])
            ->merge($kaur->pluck('id'))
            ->merge($kasi->pluck('id'))
            ->merge($kadus->pluck('id'))
            ->filter();

        // Jabatan lain di luar kategori di atas digabung ke kolom Kasi supaya tetap tampil.
        $lainnya = $pejabat->reject(fn($p) => $terpakai->contains($p->id))->values();
        $kasi = $kasi->concat($lainnya)->values();

        $adaCabangKades = $sekdes || $kasi->count() || $kadus->count();
        $adaLembaga = trim($setting->lembaga_kemasyarakatan ?? '') !== '';
        $adaBpd = trim($setting->nama_ketua_bpd ?? '') !== '';
    @endphp

    @if($kades || $sekdes || $kasi->count() || $kadus->count())

        {{-- ====== TAMPILAN MOBILE: susunan vertikal ====== --}}
        <div class="md:hidden space-y-6">

            @if($adaLembaga || $adaBpd)
                <div class="space-y-3">
                    <span class="block text-center text-[11px] font-semibold uppercase tracking-wide text-desa-ink/40">Unsur Koordinasi</span>
                    @if($adaLembaga)
                        <div class="bg-rose-50 border border-rose-200 rounded-xl p-4">
                            <h3 class="text-[11px] font-bold uppercase tracking-wide text-rose-700 mb-2">Lembaga Kemasyarakatan</h3>
                            <ul class="text-xs text-rose-900/80 space-y-1 list-disc list-inside">
                                @foreach(preg_split('/\r\n|\r|\n/', trim($setting->lembaga_kemasyarakatan)) as $lembaga)
                                    @if(trim($lembaga) !== '')
                                        <li>{{ trim($lembaga) }}</li>
                                    @endif
                                @endforeach
                            </ul>
                        </div>
                    @endif
                    @if($adaBpd)
                        @include('partials.struktur-card-row', [
                            'orang' => (object) [
                                'nama' => $setting->nama_ketua_bpd,
                                'jabatan' => 'BPD',
                                'foto' => $setting->foto_ketua_bpd,
                                'deskripsi' => null,
                            ],
                            'size' => 'md',
                        ])
                    @endif
                </div>
                <div class="flex justify-center">
                    <span class="text-desa-line text-lg leading-none">┊</span>
                </div>
            @endif

            @if($kades)
                @include('partials.struktur-card-row', ['orang' => $kades, 'size' => 'lg'])
            @endif

            @if($adaCabangKades)
                <div class="relative pl-5 border-l-2 border-desa-line space-y-5">

                    @if($sekdes)
                        <div class="relative">
                            <span class="absolute -left-[23px] top-4 w-2.5 h-2.5 rounded-full bg-desa-teal ring-4 ring-desa-bg"></span>
                            @include('partials.struktur-card-row', ['orang' => $sekdes])

                            @if($kaur->count())
                                <div class="mt-3 pl-5 border-l-2 border-desa-line/60 space-y-3">
                                    @foreach($kaur as $orang)
                                        <div class="relative">
                                            <span class="absolute -left-[19px] top-3 w-2 h-2 rounded-full bg-desa-gold ring-4 ring-desa-bg"></span>
                                            @include('partials.struktur-card-row', ['orang' => $orang])
                                        </div>
                                    @endforeach
                                </div>
                            @endif
                        </div>
                    @endif

                    @if($kasi->count())
                        <div class="relative">
                            <span class="absolute -left-[23px] top-4 w-2.5 h-2.5 rounded-full bg-desa-teal ring-4 ring-desa-bg"></span>
                            <span class="block text-[11px] font-semibold uppercase tracking-wide text-desa-ink/40 mb-2">Kepala Seksi</span>
                            <div class="space-y-3">
                                @foreach($kasi as $orang)
                                    @include('partials.struktur-card-row', ['orang' => $orang])
                                @endforeach
                            </div>
                        </div>
                    @endif

                    @if($kadus->count())
                        <div class="relative">
                            <span class="absolute -left-[23px] top-4 w-2.5 h-2.5 rounded-full bg-desa-teal ring-4 ring-desa-bg"></span>
                            <span class="block text-[11px] font-semibold uppercase tracking-wide text-desa-ink/40 mb-2">Kepala Dusun</span>
                            <div class="space-y-3">
                                @foreach($kadus as $orang)
                                    @include('partials.struktur-card-row', ['orang' => $orang])
                                @endforeach
                            </div>
                        </div>
                    @endif

                </div>
            @endif
        </div>

        {{-- ====== TAMPILAN DESKTOP/TABLET: bagan pohon (tetap seperti semula) ====== --}}
        <div class="hidden md:block overflow-x-auto pb-2">
            <div class="flex flex-col items-center min-w-max px-2">

                {{-- Baris atas: Lembaga Kemasyarakatan -- Kepala Desa -- BPD (garis koordinasi putus-putus) --}}
                <div class="flex items-center gap-4 md:gap-6">
                    @if($adaLembaga)
                        <div class="w-52 bg-rose-50 border border-rose-200 rounded-xl p-4">
                            <h3 class="text-[11px] font-bold uppercase tracking-wide text-rose-700 mb-2">Lembaga Kemasyarakatan</h3>
                            <ul class="text-xs text-rose-900/80 space-y-1 list-disc list-inside">
                                @foreach(preg_split('/\r\n|\r|\n/', trim($setting->lembaga_kemasyarakatan)) as $lembaga)
                                    @if(trim($lembaga) !== '')
                                        <li>{{ trim($lembaga) }}</li>
                                    @endif
                                @endforeach
                            </ul>
                        </div>
                        <div class="w-8 md:w-12 border-t-2 border-dashed border-desa-line"></div>
                    @endif

                    @if($kades)
                        @include('partials.struktur-card', ['orang' => $kades, 'size' => 'lg'])
                    @endif

                    @if($adaBpd)
                        <div class="w-8 md:w-12 border-t-2 border-dashed border-desa-line"></div>
                        @include('partials.struktur-card', [
                            'orang' => (object) [
                                'nama' => $setting->nama_ketua_bpd,
                                'jabatan' => 'BPD',
                                'foto' => $setting->foto_ketua_bpd,
                                'deskripsi' => null,
                            ],
                            'size' => 'md',
                        ])
                    @endif
                </div>

                @if($adaCabangKades)
                    <div class="w-px h-10 bg-desa-line"></div>

                    {{-- Cabang langsung di bawah Kepala Desa: Kaur (lewat Sekretaris Desa) di kiri, Kasi di kanan --}}
                    @if($sekdes || $kasi->count())
                        <div class="org-branch flex flex-wrap justify-center items-start">

                            @if($sekdes)
                                <div class="org-item relative flex flex-col items-center px-4 pt-8">
                                    <span class="org-stem"></span>
                                    @include('partials.struktur-card', ['orang' => $sekdes, 'size' => 'md'])

                                    @if($kaur->count())
                                        <div class="w-px h-8 bg-desa-line"></div>
                                        <div class="org-branch flex flex-wrap justify-center">
                                            @foreach($kaur as $orang)
                                                <div class="org-item relative flex flex-col items-center px-3 pt-6 pb-1">
                                                    <span class="org-stem org-stem-sm"></span>
                                                    @include('partials.struktur-card', ['orang' => $orang, 'size' => 'sm'])
                                                </div>
                                            @endforeach
                                        </div>
                                    @endif
                                </div>
                            @endif

                            @if($kasi->count())
                                <div class="org-item relative flex flex-col items-center px-4 pt-8">
                                    <span class="org-stem"></span>
                                    <div class="org-branch flex flex-wrap justify-center">
                                        @foreach($kasi as $orang)
                                            <div class="org-item relative flex flex-col items-center px-3 pt-6 pb-1">
                                                <span class="org-stem org-stem-sm"></span>
                                                @include('partials.struktur-card', ['orang' => $orang, 'size' => 'sm'])
                                            </div>
                                        @endforeach
                                    </div>
                                </div>
                            @endif

                        </div>
                    @endif

                    {{-- Kepala Dusun: baris tersendiri di paling bawah --}}
                    @if($kadus->count())
                        <div class="w-px h-10 bg-desa-line"></div>
                        <div class="org-branch flex flex-wrap justify-center">
                            @foreach($kadus as $orang)
                                <div class="org-item relative flex flex-col items-center px-3 pt-8 pb-1">
                                    <span class="org-stem"></span>
                                    @include('partials.struktur-card', ['orang' => $orang, 'size' => 'sm'])
                                </div>
                            @endforeach
                        </div>
                    @endif
                @endif

            </div>
        </div>
    @else
        <p class="text-desa-ink/40 text-center py-10">Data struktur organisasi belum diisi.</p>
    @endif
</div>

<style>
    /* Garis penghubung gaya bagan organisasi: setiap .org-item di dalam .org-branch
       yang sama akan disambung garis horizontal di bagian atasnya (kecuali ujung kiri
       & kanan), lalu turun lewat .org-stem ke kotak masing-masing. */
    .org-item {
        position: relative;
    }
    .org-item::before,
    .org-item::after {
        content: '';
        position: absolute;
        top: 0;
        width: 50%;
        height: 1px;
        background: #e7e0cd;
    }
    .org-item::before { left: 0; }
    .org-item::after  { right: 0; }
    .org-item:first-child::before,
    .org-item:last-child::after {
        background: transparent;
    }
    .org-item .org-stem {
        position: absolute;
        top: 0;
        left: 50%;
        transform: translateX(-50%);
        width: 1px;
        height: 2rem;
        background: #e7e0cd;
    }
    .org-item .org-stem-sm {
        height: 1.5rem;
    }
</style>
@endsection
