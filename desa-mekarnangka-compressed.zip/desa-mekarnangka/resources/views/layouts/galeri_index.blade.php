@extends('layouts.app')

@section('content')
<div class="max-w-6xl mx-auto px-4 py-12">
    <h1 class="text-3xl font-bold mb-8">Galeri {{ $setting->nama_desa }}</h1>

    @php $featured = $galeri->take(5); @endphp

    @if($featured->count() > 0)
        <div id="galeri-carousel" class="relative w-full mb-12" data-carousel="static">
            <!-- Carousel wrapper -->
            <div class="relative h-56 overflow-hidden rounded-xl md:h-96">
                @foreach($featured as $i => $foto)
                    <div class="{{ $i === 0 ? '' : 'hidden' }} duration-700 ease-in-out" data-carousel-item="{{ $i === 0 ? 'active' : '' }}">
                        <img src="{{ asset('storage/'.$foto->foto) }}"
                             class="absolute block w-full h-full object-cover -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2"
                             alt="{{ $foto->judul }}">
                        <div class="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/70 to-transparent text-white p-4">
                            <p class="text-sm font-medium">{{ $foto->judul }}</p>
                        </div>
                    </div>
                @endforeach
            </div>

            <!-- Slider indicators -->
            <div class="absolute z-30 flex -translate-x-1/2 bottom-5 left-1/2 space-x-3 rtl:space-x-reverse">
                @foreach($featured as $i => $foto)
                    <button type="button"
                            class="w-3 h-3 rounded-full"
                            aria-current="{{ $i === 0 ? 'true' : 'false' }}"
                            aria-label="Slide {{ $i + 1 }}"
                            data-carousel-slide-to="{{ $i }}"></button>
                @endforeach
            </div>

            <!-- Slider controls -->
            <button type="button" class="absolute top-0 start-0 z-30 flex items-center justify-center h-full px-4 cursor-pointer group focus:outline-none" data-carousel-prev>
                <span class="inline-flex items-center justify-center w-10 h-10 rounded-full bg-white/30 group-hover:bg-white/50 group-focus:ring-4 group-focus:ring-white group-focus:outline-none">
                    <svg class="w-5 h-5 text-white rtl:rotate-180" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24"><path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m15 19-7-7 7-7"/></svg>
                    <span class="sr-only">Sebelumnya</span>
                </span>
            </button>
            <button type="button" class="absolute top-0 end-0 z-30 flex items-center justify-center h-full px-4 cursor-pointer group focus:outline-none" data-carousel-next>
                <span class="inline-flex items-center justify-center w-10 h-10 rounded-full bg-white/30 group-hover:bg-white/50 group-focus:ring-4 group-focus:ring-white group-focus:outline-none">
                    <svg class="w-5 h-5 text-white rtl:rotate-180" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24"><path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m9 5 7 7-7 7"/></svg>
                    <span class="sr-only">Berikutnya</span>
                </span>
            </button>
        </div>
    @endif

    <h2 class="text-xl font-semibold mb-4">Semua Foto</h2>
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
        @forelse($galeri as $i => $foto)
            <button
                type="button"
                class="lightbox-trigger rounded-xl overflow-hidden shadow bg-gray-200 text-left cursor-pointer hover:opacity-90 transition"
                data-index="{{ $i }}"
            >
                <img src="{{ asset('storage/'.$foto->foto) }}" class="w-full h-48 object-cover pointer-events-none">
                <div class="p-2 text-xs text-gray-500">{{ $foto->judul }}</div>
            </button>
        @empty
            <p class="text-gray-400 col-span-full">Belum ada foto.</p>
        @endforelse
    </div>

    <div class="mt-8">
        {{ $galeri->links() }}
    </div>
</div>

<!-- Lightbox overlay -->
<div id="lightbox" class="fixed inset-0 z-[100] hidden items-center justify-center bg-black/90 p-4">
    <button id="lightbox-close" type="button" class="absolute top-4 right-4 text-white/80 hover:text-white z-10">
        <svg class="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
            <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
        </svg>
    </button>

    <button id="lightbox-prev" type="button" class="absolute left-2 md:left-6 top-1/2 -translate-y-1/2 text-white/80 hover:text-white">
        <svg class="w-9 h-9" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
            <path stroke-linecap="round" stroke-linejoin="round" d="m15 19-7-7 7-7" />
        </svg>
    </button>
    <button id="lightbox-next" type="button" class="absolute right-2 md:right-6 top-1/2 -translate-y-1/2 text-white/80 hover:text-white">
        <svg class="w-9 h-9" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
            <path stroke-linecap="round" stroke-linejoin="round" d="m9 5 7 7-7 7" />
        </svg>
    </button>

    <div class="max-w-4xl w-full flex flex-col items-center">
        <img id="lightbox-img" src="" alt="" class="max-h-[75vh] w-auto rounded-lg shadow-lg object-contain">
        <p id="lightbox-caption" class="text-white/90 text-sm mt-3"></p>
        <p id="lightbox-position" class="text-white/50 text-xs mt-1"></p>
    </div>
</div>

<script>
(function () {
    const photos = [
        @foreach($galeri as $foto)
        { src: "{{ asset('storage/'.$foto->foto) }}", caption: "{{ addslashes($foto->judul) }}" },
        @endforeach
    ];

    const lightbox = document.getElementById('lightbox');
    const lightboxImg = document.getElementById('lightbox-img');
    const lightboxCaption = document.getElementById('lightbox-caption');
    const lightboxPosition = document.getElementById('lightbox-position');
    let currentIndex = 0;

    function showPhoto(index) {
        if (photos.length === 0) return;
        currentIndex = (index + photos.length) % photos.length;
        const photo = photos[currentIndex];
        lightboxImg.src = photo.src;
        lightboxImg.alt = photo.caption;
        lightboxCaption.textContent = photo.caption;
        lightboxPosition.textContent = (currentIndex + 1) + ' / ' + photos.length;
    }

    function openLightbox(index) {
        showPhoto(index);
        lightbox.classList.remove('hidden');
        lightbox.classList.add('flex');
        document.body.style.overflow = 'hidden';
    }

    function closeLightbox() {
        lightbox.classList.add('hidden');
        lightbox.classList.remove('flex');
        document.body.style.overflow = '';
    }

    document.querySelectorAll('.lightbox-trigger').forEach(function (btn) {
        btn.addEventListener('click', function () {
            openLightbox(parseInt(btn.dataset.index, 10));
        });
    });

    document.getElementById('lightbox-close').addEventListener('click', closeLightbox);
    document.getElementById('lightbox-prev').addEventListener('click', function () {
        showPhoto(currentIndex - 1);
    });
    document.getElementById('lightbox-next').addEventListener('click', function () {
        showPhoto(currentIndex + 1);
    });

    // Klik di area gelap luar foto -> tutup
    lightbox.addEventListener('click', function (e) {
        if (e.target === lightbox) closeLightbox();
    });

    // Navigasi keyboard
    document.addEventListener('keydown', function (e) {
        if (lightbox.classList.contains('hidden')) return;
        if (e.key === 'Escape') closeLightbox();
        if (e.key === 'ArrowLeft') showPhoto(currentIndex - 1);
        if (e.key === 'ArrowRight') showPhoto(currentIndex + 1);
    });
})();
</script>
@endsection
