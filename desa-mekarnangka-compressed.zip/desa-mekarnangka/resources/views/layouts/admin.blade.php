<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - @yield('title', 'Dashboard')</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        'desa-teal-dark': '#0f3d3b',
                        'desa-teal': '#1f6f63',
                        'desa-tosca': '#4fae9b',
                        'desa-gold': '#d4a72c',
                        'desa-cream': '#f4efe1',
                    }
                }
            }
        }
    </script>
</head>
@php
    $__navSetting = \App\Models\Setting::current();
@endphp
<body class="bg-gray-100 flex min-h-screen">

    <!-- Topbar khusus mobile -->
    <div class="md:hidden fixed top-0 inset-x-0 z-40 text-white flex items-center justify-between px-4 py-3 shadow" style="background: linear-gradient(to right, #0f3d3b, #1f6f63, #4fae9b);">
        <div class="flex items-center gap-2 font-bold">
            <img src="{{ asset('images/logo-mekarnangka.png') }}" alt="Logo" class="w-7 h-7 rounded-full object-cover">
            <span>Admin Desa</span>
        </div>
        <button
            id="admin-sidebar-button"
            type="button"
            class="p-2 rounded-lg hover:bg-white/10 transition"
            aria-controls="admin-sidebar"
            aria-expanded="false"
            aria-label="Buka menu admin"
        >
            <svg id="admin-icon-burger" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h16" />
            </svg>
            <svg id="admin-icon-close" class="h-6 w-6 hidden" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
        </button>
    </div>

    <!-- Backdrop, muncul di belakang sidebar saat dibuka di mobile -->
    <div
        id="admin-sidebar-backdrop"
        class="md:hidden hidden fixed inset-0 bg-black/50 z-40"
    ></div>

    <aside
        id="admin-sidebar"
        class="w-64 text-white flex-shrink-0 fixed inset-y-0 left-0 z-50 -translate-x-full transition-transform duration-200 ease-in-out md:static md:translate-x-0 md:block"
        style="background: linear-gradient(to bottom, #0f3d3b, #1f6f63, #4fae9b);"
    >
        <div class="p-5 font-bold text-lg border-b border-white/10 flex items-center gap-2">
            <img src="{{ asset('images/logo-mekarnangka.png') }}" alt="Logo" class="w-8 h-8 rounded-full object-cover">
            <span>Admin Desa</span>
        </div>
        <nav class="p-4 space-y-1 text-sm">
            <a href="{{ route('admin.dashboard') }}" class="block px-3 py-2 rounded-lg hover:bg-white/10 transition">Dashboard</a>
            <a href="{{ route('admin.articles.index') }}" class="block px-3 py-2 rounded-lg hover:bg-white/10 transition">Berita</a>
            <a href="{{ route('admin.layanan.index') }}" class="block px-3 py-2 rounded-lg hover:bg-white/10 transition">Layanan</a>
            <a href="{{ route('admin.officials.index') }}" class="block px-3 py-2 rounded-lg hover:bg-white/10 transition">Struktur Organisasi</a>
            <a href="{{ route('admin.galleries.index') }}" class="block px-3 py-2 rounded-lg hover:bg-white/10 transition">Galeri</a>
            <a href="{{ route('admin.population-stats.index') }}" class="block px-3 py-2 rounded-lg hover:bg-white/10 transition">Statistik Penduduk</a>
            <a href="{{ route('admin.settings.edit') }}" class="block px-3 py-2 rounded-lg hover:bg-white/10 transition">Pengaturan Desa</a>
            <a href="{{ route('home') }}" target="_blank" rel="noopener noreferrer" class="block px-3 py-2 rounded-lg hover:bg-white/10 transition mt-4 text-desa-gold">&larr; Lihat Website</a>
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button class="w-full text-left px-3 py-2 rounded-lg hover:bg-white/10 transition text-red-300">Logout</button>
            </form>
        </nav>
    </aside>

    <main class="flex-1 p-6 md:p-8 pt-20 md:pt-8">
        @if(session('status'))
            <div class="mb-4 bg-green-100 text-green-800 px-4 py-3 rounded-lg text-sm">
                {{ session('status') }}
            </div>
        @endif
        @yield('content')
    </main>

    <script>
        (function () {
            const btn = document.getElementById('admin-sidebar-button');
            const sidebar = document.getElementById('admin-sidebar');
            const backdrop = document.getElementById('admin-sidebar-backdrop');
            const iconBurger = document.getElementById('admin-icon-burger');
            const iconClose = document.getElementById('admin-icon-close');

            if (!btn || !sidebar || !backdrop) return;

            function closeSidebar() {
                sidebar.classList.add('-translate-x-full');
                backdrop.classList.add('hidden');
                iconBurger.classList.remove('hidden');
                iconClose.classList.add('hidden');
                btn.setAttribute('aria-expanded', 'false');
            }

            function openSidebar() {
                sidebar.classList.remove('-translate-x-full');
                backdrop.classList.remove('hidden');
                iconBurger.classList.add('hidden');
                iconClose.classList.remove('hidden');
                btn.setAttribute('aria-expanded', 'true');
            }

            btn.addEventListener('click', function () {
                const isOpen = !sidebar.classList.contains('-translate-x-full');
                isOpen ? closeSidebar() : openSidebar();
            });

            backdrop.addEventListener('click', closeSidebar);

            // Tutup otomatis kalau salah satu link di sidebar diklik (mobile).
            sidebar.querySelectorAll('a').forEach(function (link) {
                link.addEventListener('click', function () {
                    if (window.innerWidth < 768) closeSidebar();
                });
            });

            // Reset saat layar di-resize ke ukuran desktop.
            window.addEventListener('resize', function () {
                if (window.innerWidth >= 768) closeSidebar();
            });
        })();
    </script>

</body>
</html>
