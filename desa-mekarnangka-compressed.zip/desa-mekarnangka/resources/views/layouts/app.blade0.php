<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', ($setting->nama_desa ?? 'Desa Mekarnangka'))</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        'desa-teal-dark': '#0f3d3b',
                        'desa-teal': '#1f6f63',
                        'desa-tosca': '#4fae9b',
                        'desa-gold': '#d4a72c',
                        'desa-cream': '#f4efe1',
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-[#eaf5f2] text-gray-800">

   <header class="text-white sticky top-0 z-50 shadow" style="background: linear-gradient(to right, #0f3d3b, #1f6f63, #4fae9b);">
        <div class="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
            <a href="{{ route('home') }}" class="flex items-center gap-3 font-bold text-lg leading-tight">
                @if($setting->logo ?? false)
                    <img src="{{ asset('storage/'.$setting->logo) }}" class="h-10 w-10 rounded-full bg-white p-1 object-contain flex-shrink-0">
                @endif
                <span>{{ $setting->nama_desa ?? 'Desa Mekarnangka' }}</span>
            </a>

            <nav class="hidden md:flex gap-6 text-sm font-medium">
                <a href="{{ route('home') }}" class="hover:text-desa-gold transition">Beranda</a>
                <a href="{{ route('profil') }}" class="hover:text-desa-gold transition">Profil</a>
                <a href="{{ route('struktur') }}" class="hover:text-desa-gold transition">Struktur</a>
                <a href="{{ route('statistik') }}" class="hover:text-desa-gold transition">Statistik</a>
                <a href="{{ route('artikel.index') }}" class="hover:text-desa-gold transition">Berita</a>
                <a href="{{ route('galeri.index') }}" class="hover:text-desa-gold transition">Galeri</a>
                <a href="{{ route('kontak') }}" class="hover:text-desa-gold transition">Kontak</a>
            </nav>

            <button
                id="mobile-menu-button"
                type="button"
                class="md:hidden inline-flex items-center justify-center p-2 rounded-lg hover:bg-white/10 transition"
                aria-controls="mobile-menu"
                aria-expanded="false"
                aria-label="Buka menu navigasi"
            >
                <svg id="icon-burger" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h16" />
                </svg>
                <svg id="icon-close" class="h-6 w-6 hidden" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
                </svg>
            </button>
        </div>

        <nav
            id="mobile-menu"
            class="md:hidden hidden flex-col gap-1 px-4 pb-4 text-sm font-medium border-t border-white/10"
        >
            <a href="{{ route('home') }}" class="block py-2 px-2 rounded-lg hover:bg-white/10 transition">Beranda</a>
            <a href="{{ route('profil') }}" class="block py-2 px-2 rounded-lg hover:bg-white/10 transition">Profil</a>
            <a href="{{ route('struktur') }}" class="block py-2 px-2 rounded-lg hover:bg-white/10 transition">Struktur</a>
            <a href="{{ route('statistik') }}" class="block py-2 px-2 rounded-lg hover:bg-white/10 transition">Statistik</a>
            <a href="{{ route('artikel.index') }}" class="block py-2 px-2 rounded-lg hover:bg-white/10 transition">Berita</a>
            <a href="{{ route('galeri.index') }}" class="block py-2 px-2 rounded-lg hover:bg-white/10 transition">Galeri</a>
            <a href="{{ route('kontak') }}" class="block py-2 px-2 rounded-lg hover:bg-white/10 transition">Kontak</a>
        </nav>
    </header>

    <script>
        (function () {
            const btn = document.getElementById('mobile-menu-button');
            const menu = document.getElementById('mobile-menu');
            const iconBurger = document.getElementById('icon-burger');
            const iconClose = document.getElementById('icon-close');

            if (!btn || !menu) return;

            function closeMenu() {
                menu.classList.add('hidden');
                menu.classList.remove('flex');
                iconBurger.classList.remove('hidden');
                iconClose.classList.add('hidden');
                btn.setAttribute('aria-expanded', 'false');
            }

            function openMenu() {
                menu.classList.remove('hidden');
                menu.classList.add('flex');
                iconBurger.classList.add('hidden');
                iconClose.classList.remove('hidden');
                btn.setAttribute('aria-expanded', 'true');
            }

            btn.addEventListener('click', function () {
                const isOpen = !menu.classList.contains('hidden');
                isOpen ? closeMenu() : openMenu();
            });

            // Tutup menu otomatis kalau salah satu link diklik.
            menu.querySelectorAll('a').forEach(function (link) {
                link.addEventListener('click', closeMenu);
            });

            // Tutup menu otomatis kalau layar di-resize ke ukuran desktop.
            window.addEventListener('resize', function () {
                if (window.innerWidth >= 768) closeMenu();
            });
        })();
    </script>

    <main>
        @yield('content')
    </main>

    <footer class="text-white" style="background: linear-gradient(to bottom, #1f6f63, #0f3d3b);">
        <div class="mx-auto w-full max-w-screen-xl p-4 py-6 lg:py-8">
            <div class="md:flex md:justify-between">
                <div class="mb-6 md:mb-0">
                    <a href="{{ route('home') }}" class="flex items-center gap-3">
                        @if($setting->logo ?? false)
                            <img src="{{ asset('storage/'.$setting->logo) }}" class="h-10 w-10 rounded-full bg-white p-1 object-contain flex-shrink-0" alt="Logo {{ $setting->nama_desa ?? 'Desa' }}" />
                        @endif
                        <span class="text-white text-lg font-bold leading-tight whitespace-nowrap">{{ $setting->nama_desa ?? 'Desa Mekarnangka' }}</span>
                    </a>
                    <p class="mt-3 text-sm text-desa-cream/70 max-w-xs">{{ $setting->alamat_kantor ?? '' }}</p>
                </div>
                <div class="grid grid-cols-2 gap-8 sm:gap-6 sm:grid-cols-3">
                    <div>
                        <h2 class="mb-6 text-sm font-semibold text-desa-gold uppercase">Tautan</h2>
                        <ul class="text-desa-cream/80 font-medium">
                            <li class="mb-4">
                                <a href="{{ route('profil') }}" class="hover:text-desa-gold transition">Profil Desa</a>
                            </li>
                            <li class="mb-4">
                                <a href="{{ route('struktur') }}" class="hover:text-desa-gold transition">Struktur Organisasi</a>
                            </li>
                            <li>
                                <a href="{{ route('statistik') }}" class="hover:text-desa-gold transition">Statistik Penduduk</a>
                            </li>
                        </ul>
                    </div>
                    <div>
                        <h2 class="mb-6 text-sm font-semibold text-desa-gold uppercase">Informasi</h2>
                        <ul class="text-desa-cream/80 font-medium">
                            <li class="mb-4">
                                <a href="{{ route('artikel.index') }}" class="hover:text-desa-gold transition">Berita Desa</a>
                            </li>
                            <li>
                                <a href="{{ route('galeri.index') }}" class="hover:text-desa-gold transition">Galeri</a>
                            </li>
                        </ul>
                    </div>
                    <div>
                        <h2 class="mb-6 text-sm font-semibold text-desa-gold uppercase">Kontak</h2>
                        <ul class="text-desa-cream/80 font-medium">
                            <li class="mb-4">
                                <a href="mailto:{{ $setting->email ?? '' }}" class="hover:text-desa-gold transition">{{ $setting->email ?? '-' }}</a>
                            </li>
                            <li>
                                <a href="tel:{{ $setting->telepon ?? '' }}" class="hover:text-desa-gold transition">{{ $setting->telepon ?? '-' }}</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <hr class="my-6 border-white/10 sm:mx-auto lg:my-8" />
            <div class="sm:flex sm:items-center sm:justify-between">
                <span class="text-sm text-desa-cream/70 sm:text-center">
                    &copy; {{ date('Y') }} <a href="{{ route('home') }}" class="hover:text-desa-gold transition">{{ $setting->nama_desa ?? 'Desa Mekarnangka' }}</a>. Semua hak dilindungi.
                </span>
                <div class="flex mt-4 sm:justify-center sm:mt-0">
                    @if($setting->facebook ?? false)
                    <a href="{{ $setting->facebook }}" target="_blank" class="text-desa-cream/70 hover:text-desa-gold transition">
                        <svg class="w-5 h-5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24"><path fill-rule="evenodd" d="M13.135 6H15V3h-1.865a4.147 4.147 0 0 0-4.142 4.142V9H7v3h2v9.938h3V12h2.021l.592-3H12V6.591A.6.6 0 0 1 12.592 6h.543Z" clip-rule="evenodd"/></svg>
                        <span class="sr-only">Facebook</span>
                    </a>
                    @endif
                    @if($setting->instagram ?? false)
                    <a href="{{ $setting->instagram }}" target="_blank" class="text-desa-cream/70 hover:text-desa-gold transition ms-5">
                        <svg class="w-5 h-5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24"><path fill-rule="evenodd" d="M12.006 2a9.847 9.847 0 0 0-6.484 2.44 10.32 10.32 0 0 0-3.393 6.17 10.48 10.48 0 0 0 1.317 6.955 10.045 10.045 0 0 0 5.4 4.418c.504.095.683-.223.683-.494 0-.245-.01-1.052-.014-1.908-2.78.62-3.366-1.21-3.366-1.21a2.711 2.711 0 0 0-1.11-1.5c-.907-.637.07-.621.07-.621.317.044.62.163.885.346.266.183.487.426.647.71.135.253.318.476.538.655a2.079 2.079 0 0 0 2.37.196c.045-.52.27-1.006.635-1.37-2.219-.259-4.554-1.138-4.554-5.07a4.022 4.022 0 0 1 1.031-2.75 3.77 3.77 0 0 1 .096-2.713s.839-.275 2.749 1.05a9.26 9.26 0 0 1 5.004 0c1.906-1.325 2.74-1.05 2.74-1.05.37.858.406 1.828.101 2.713a4.017 4.017 0 0 1 1.029 2.75c0 3.939-2.339 4.805-4.564 5.058a2.471 2.471 0 0 1 .679 1.897c0 1.372-.012 2.477-.012 2.814 0 .272.18.592.687.492a10.05 10.05 0 0 0 5.388-4.421 10.473 10.473 0 0 0 1.313-6.948 10.32 10.32 0 0 0-3.39-6.165A9.847 9.847 0 0 0 12.007 2Z" clip-rule="evenodd"/></svg>
                        <span class="sr-only">Instagram</span>
                    </a>
                    @endif
                    @if($setting->youtube ?? false)
                    <a href="{{ $setting->youtube }}" target="_blank" class="text-desa-cream/70 hover:text-desa-gold transition ms-5">
                        <svg class="w-5 h-5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24"><path fill-rule="evenodd" d="M21.7 8.037a4.26 4.26 0 0 0-.789-1.964 2.84 2.84 0 0 0-1.984-.839c-2.767-.2-6.926-.2-6.926-.2s-4.157 0-6.928.2a2.836 2.836 0 0 0-1.983.839 4.225 4.225 0 0 0-.79 1.965 30.146 30.146 0 0 0-.2 3.206v1.5a30.12 30.12 0 0 0 .2 3.206c.094.712.364 1.39.789 1.965a3.36 3.36 0 0 0 2.353.833c1.703.164 7.234.216 7.234.216s4.162-.006 6.933-.207a2.836 2.836 0 0 0 1.983-.839 4.26 4.26 0 0 0 .79-1.965 30.12 30.12 0 0 0 .2-3.206v-1.5a30.245 30.245 0 0 0-.202-3.206Zm-11.692 6.554v-5.62l5.4 2.819-5.4 2.801Z" clip-rule="evenodd"/></svg>
                        <span class="sr-only">YouTube</span>
                    </a>
                    @endif
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.js"></script>

</body>
</html>