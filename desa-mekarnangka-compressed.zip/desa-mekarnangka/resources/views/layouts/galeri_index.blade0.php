@extends('layouts.app')

@section('content')
<div class="max-w-6xl mx-auto px-4 py-12">
    <h1 class="text-3xl font-bold mb-8">Galeri {{ $setting->nama_desa }}</h1>

    @php $featured = $galeri->take(5); @endphp

    @if($featured->count() > 0)
        <div id="galeri-carousel" class="relative w-full mb-12" data-carousel="static">
            <!-- Carousel wrapper -->
            <div class="relative h-56 overflow-hidden rounded-xl md:h-96">
                @foreach($featured as $i => $foto)
                    <div class="{{ $i === 0 ? '' : 'hidden' }} duration-700 ease-in-out" data-carousel-item="{{ $i === 0 ? 'active' : '' }}">
                        <img src="{{ asset('storage/'.$foto->foto) }}"
                             class="absolute block w-full h-full object-cover -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2"
                             alt="{{ $foto->judul }}">
                        <div class="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/70 to-transparent text-white p-4">
                            <p class="text-sm font-medium">{{ $foto->judul }}</p>
                        </div>
                    </div>
                @endforeach
            </div>

            <!-- Slider indicators -->
            <div class="absolute z-30 flex -translate-x-1/2 bottom-5 left-1/2 space-x-3 rtl:space-x-reverse">
                @foreach($featured as $i => $foto)
                    <button type="button"
                            class="w-3 h-3 rounded-full"
                            aria-current="{{ $i === 0 ? 'true' : 'false' }}"
                            aria-label="Slide {{ $i + 1 }}"
                            data-carousel-slide-to="{{ $i }}"></button>
                @endforeach
            </div>

            <!-- Slider controls -->
            <button type="button" class="absolute top-0 start-0 z-30 flex items-center justify-center h-full px-4 cursor-pointer group focus:outline-none" data-carousel-prev>
                <span class="inline-flex items-center justify-center w-10 h-10 rounded-full bg-white/30 group-hover:bg-white/50 group-focus:ring-4 group-focus:ring-white group-focus:outline-none">
                    <svg class="w-5 h-5 text-white rtl:rotate-180" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24"><path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m15 19-7-7 7-7"/></svg>
                    <span class="sr-only">Sebelumnya</span>
                </span>
            </button>
            <button type="button" class="absolute top-0 end-0 z-30 flex items-center justify-center h-full px-4 cursor-pointer group focus:outline-none" data-carousel-next>
                <span class="inline-flex items-center justify-center w-10 h-10 rounded-full bg-white/30 group-hover:bg-white/50 group-focus:ring-4 group-focus:ring-white group-focus:outline-none">
                    <svg class="w-5 h-5 text-white rtl:rotate-180" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24"><path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m9 5 7 7-7 7"/></svg>
                    <span class="sr-only">Berikutnya</span>
                </span>
            </button>
        </div>
    @endif
    

    <h2 class="text-xl font-semibold mb-4">Semua Foto</h2>
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
        @forelse($galeri as $foto)
            <div class="rounded-xl overflow-hidden shadow bg-gray-200">
                <img src="{{ asset('storage/'.$foto->foto) }}" class="w-full h-48 object-cover">
                <div class="p-2 text-xs text-gray-500">{{ $foto->judul }}</div>
            </div>
        @empty
            <p class="text-gray-400 col-span-full">Belum ada foto.</p>
        @endforelse
    </div>

    <div class="mt-8">
        {{ $galeri->links() }}
    </div>
</div>
@endsection
