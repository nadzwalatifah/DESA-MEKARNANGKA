@extends('layouts.app')

@section('content')
<div class="max-w-5xl mx-auto px-4 py-16">
    <span class="text-[11px] font-semibold uppercase tracking-[0.18em] text-desa-teal">Data Kependudukan</span>
    <h1 class="font-display text-3xl md:text-4xl font-semibold mt-2 mb-10">Statistik Penduduk {{ $setting->nama_desa }}</h1>

    @if($stats->isNotEmpty())
        @php
            $dusunLabels = $stats->pluck('dusun');
            $lakiData = $stats->pluck('laki_laki');
            $perempuanData = $stats->pluck('perempuan');
            $totalLaki = $stats->sum('laki_laki');
            $totalPerempuan = $stats->sum('perempuan');
            $totalKk = $stats->sum('jumlah_kk');
            $totalJiwa = $totalLaki + $totalPerempuan;
        @endphp

        {{-- RINGKASAN ANGKA --}}
        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10 text-center">
            <div class="bg-desa-teal-dark/[0.04] border border-desa-line rounded-xl p-5">
                <p class="text-xs text-desa-ink/50 mb-1">Jumlah KK</p>
                <p class="font-display font-semibold text-lg text-desa-teal-dark">{{ $totalKk }}</p>
            </div>
            <div class="bg-desa-teal-dark/[0.04] border border-desa-line rounded-xl p-5">
                <p class="text-xs text-desa-ink/50 mb-1">Total Jiwa</p>
                <p class="font-display font-semibold text-lg text-desa-teal-dark">{{ $totalJiwa }}</p>
            </div>
            <div class="bg-desa-teal-dark/[0.04] border border-desa-line rounded-xl p-5">
                <p class="text-xs text-desa-ink/50 mb-1">Laki-laki</p>
                <p class="font-display font-semibold text-lg text-desa-teal-dark">{{ $totalLaki }}</p>
            </div>
            <div class="bg-desa-teal-dark/[0.04] border border-desa-line rounded-xl p-5">
                <p class="text-xs text-desa-ink/50 mb-1">Perempuan</p>
                <p class="font-display font-semibold text-lg text-desa-teal-dark">{{ $totalPerempuan }}</p>
            </div>
        </div>

        {{-- GRAFIK --}}
        <div class="grid md:grid-cols-3 gap-6 mb-12">
            <div class="md:col-span-2 bg-white border border-desa-line rounded-xl shadow-sm p-6">
                <h2 class="font-display font-semibold text-desa-teal-dark mb-4">Penduduk per Dusun</h2>
                <div class="h-72">
                    <canvas id="chartDusun"></canvas>
                </div>
            </div>
            <div class="bg-white border border-desa-line rounded-xl shadow-sm p-6">
                <h2 class="font-display font-semibold text-desa-teal-dark mb-4">Komposisi Jenis Kelamin</h2>
                <div class="h-72">
                    <canvas id="chartGender"></canvas>
                </div>
            </div>
        </div>
    @endif

    <div class="overflow-x-auto bg-white rounded-xl border border-desa-line shadow-sm">
        <table class="w-full text-sm text-left">
            <thead class="text-white" style="background: linear-gradient(to right, #0f3d3b, #1f6f63);">
                <tr>
                    <th class="px-5 py-4 font-display font-semibold">Dusun</th>
                    <th class="px-5 py-4 font-display font-semibold">Tahun</th>
                    <th class="px-5 py-4 font-display font-semibold">Jumlah KK</th>
                    <th class="px-5 py-4 font-display font-semibold">Laki-laki</th>
                    <th class="px-5 py-4 font-display font-semibold">Perempuan</th>
                    <th class="px-5 py-4 font-display font-semibold">Total Jiwa</th>
                </tr>
            </thead>
            <tbody>
                @forelse($stats as $s)
                    <tr class="border-b border-desa-line last:border-0 odd:bg-desa-bg/60 hover:bg-desa-gold-soft/10 transition">
                        <td class="px-5 py-4">{{ $s->dusun }}</td>
                        <td class="px-5 py-4">{{ $s->tahun }}</td>
                        <td class="px-5 py-4">{{ $s->jumlah_kk }}</td>
                        <td class="px-5 py-4">{{ $s->laki_laki }}</td>
                        <td class="px-5 py-4">{{ $s->perempuan }}</td>
                        <td class="px-5 py-4 font-semibold text-desa-teal-dark">{{ $s->laki_laki + $s->perempuan }}</td>
                    </tr>
                @empty
                    <tr><td class="px-5 py-10 text-desa-ink/40 text-center" colspan="6">Data statistik belum diisi.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

@if($stats->isNotEmpty())
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>
<script>
    (function () {
        const dusunLabels = @json($dusunLabels);
        const lakiData = @json($lakiData);
        const perempuanData = @json($perempuanData);
        const totalLaki = {{ $totalLaki }};
        const totalPerempuan = {{ $totalPerempuan }};

        const inkColor = '#1c2b27';
        const lineColor = '#e7e0cd';

        Chart.defaults.font.family = "'Plus Jakarta Sans', sans-serif";
        Chart.defaults.color = inkColor;

        new Chart(document.getElementById('chartDusun'), {
            type: 'bar',
            data: {
                labels: dusunLabels,
                datasets: [
                    {
                        label: 'Laki-laki',
                        data: lakiData,
                        backgroundColor: '#1f6f63',
                        borderRadius: 6,
                        maxBarThickness: 36,
                    },
                    {
                        label: 'Perempuan',
                        data: perempuanData,
                        backgroundColor: '#c9962f',
                        borderRadius: 6,
                        maxBarThickness: 36,
                    },
                ],
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'bottom', labels: { boxWidth: 12, usePointStyle: true, pointStyle: 'circle' } },
                },
                scales: {
                    x: { grid: { display: false } },
                    y: { beginAtZero: true, grid: { color: lineColor }, ticks: { precision: 0 } },
                },
            },
        });

        new Chart(document.getElementById('chartGender'), {
            type: 'doughnut',
            data: {
                labels: ['Laki-laki', 'Perempuan'],
                datasets: [{
                    data: [totalLaki, totalPerempuan],
                    backgroundColor: ['#1f6f63', '#c9962f'],
                    borderWidth: 0,
                }],
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '65%',
                plugins: {
                    legend: { position: 'bottom', labels: { boxWidth: 12, usePointStyle: true, pointStyle: 'circle' } },
                },
            },
        });
    })();
</script>
@endif
@endsection
