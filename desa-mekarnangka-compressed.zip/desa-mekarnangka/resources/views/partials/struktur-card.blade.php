@php
    $size = $size ?? 'sm';

    $dimensiFoto = match($size) {
        'lg' => 'w-32 h-32',
        'md' => 'w-24 h-24',
        default => 'w-20 h-20',
    };

    $namaKelas = match($size) {
        'lg' => 'text-lg',
        'md' => 'text-base',
        default => 'text-sm',
    };

    $paddingKartu = match($size) {
        'lg' => 'px-6 py-7',
        'md' => 'px-5 py-6',
        default => 'px-4 py-5',
    };

    $inisial = collect(explode(' ', $orang->nama ?? '-'))
        ->filter()
        ->map(fn($w) => strtoupper(substr($w, 0, 1)))
        ->take(2)
        ->implode('');
@endphp

<div class="flex flex-col items-center text-center bg-white border border-desa-line rounded-2xl shadow-sm {{ $paddingKartu }} w-[190px]">
    <div class="{{ $dimensiFoto }} rounded-full overflow-hidden bg-desa-teal/10 border-2 border-desa-gold-soft flex items-center justify-center flex-shrink-0">
        @if($orang->foto ?? false)
            <img src="{{ asset('storage/'.$orang->foto) }}" class="w-full h-full object-cover" alt="{{ $orang->nama }}">
        @else
            <span class="font-display font-semibold text-desa-teal">{{ $inisial }}</span>
        @endif
    </div>

    <h3 class="font-display font-semibold {{ $namaKelas }} mt-4 leading-tight">{{ $orang->nama }}</h3>

    <span class="mt-1.5 inline-block text-[10px] font-semibold uppercase tracking-wide text-desa-teal bg-desa-teal/10 rounded-full px-3 py-1">
        {{ $orang->jabatan }}
    </span>

    @if($orang->deskripsi ?? false)
        <p class="mt-3 text-xs text-desa-ink/50 leading-relaxed">{{ $orang->deskripsi }}</p>
    @endif
</div>
