@php
    $size = $size ?? 'sm';

    $dimensiFoto = match($size) {
        'lg' => 'w-16 h-16',
        default => 'w-14 h-14',
    };

    $namaKelas = match($size) {
        'lg' => 'text-base',
        default => 'text-sm',
    };

    $inisial = collect(explode(' ', $orang->nama ?? '-'))
        ->filter()
        ->map(fn($w) => strtoupper(substr($w, 0, 1)))
        ->take(2)
        ->implode('');
@endphp

<div class="flex items-center gap-3 text-left bg-white border border-desa-line rounded-xl shadow-sm px-3 py-3 w-full">
    <div class="{{ $dimensiFoto }} rounded-full overflow-hidden bg-desa-teal/10 border-2 border-desa-gold-soft flex items-center justify-center flex-shrink-0">
        @if($orang->foto ?? false)
            <img src="{{ asset('storage/'.$orang->foto) }}" class="w-full h-full object-cover" alt="{{ $orang->nama }}">
        @else
            <span class="font-display font-semibold text-desa-teal text-sm">{{ $inisial }}</span>
        @endif
    </div>

    <div class="min-w-0">
        <h3 class="font-display font-semibold {{ $namaKelas }} leading-tight truncate">{{ $orang->nama }}</h3>
        <span class="mt-1 inline-block text-[10px] font-semibold uppercase tracking-wide text-desa-teal bg-desa-teal/10 rounded-full px-2.5 py-0.5">
            {{ $orang->jabatan }}
        </span>
        @if($orang->deskripsi ?? false)
            <p class="mt-1 text-xs text-desa-ink/50 leading-relaxed">{{ $orang->deskripsi }}</p>
        @endif
    </div>
</div>
