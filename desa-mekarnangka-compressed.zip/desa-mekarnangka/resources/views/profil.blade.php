@extends('layouts.app')

@section('content')
<div class="max-w-5xl mx-auto px-4 py-16 space-y-10">
    <div>
        <span class="text-[11px] font-semibold uppercase tracking-[0.18em] text-desa-teal">Tentang Kami</span>
        <h1 class="font-display text-3xl md:text-4xl font-semibold mt-2 mb-4">Profil {{ $setting->nama_desa }}</h1>
        <p class="text-desa-ink/70 leading-relaxed max-w-3xl">{{ $setting->sejarah ?? 'Sejarah desa belum diisi.' }}</p>
    </div>

    <div class="grid md:grid-cols-2 gap-6 items-start">
        <div class="bg-white rounded-xl border border-desa-line shadow-sm p-6 border-l-4 border-l-desa-gold">
            <h2 class="font-display font-semibold text-lg mb-3 text-desa-teal-dark">Visi</h2>
            <p class="text-desa-ink/70 leading-relaxed italic">&ldquo;{{ $setting->visi ?? '-' }}&rdquo;</p>
        </div>
        <div class="bg-white rounded-xl border border-desa-line shadow-sm p-6 border-l-4 border-l-desa-gold">
            <h2 class="font-display font-semibold text-lg mb-3 text-desa-teal-dark">Misi</h2>
            @php
                $daftarMisi = collect(preg_split('/\r\n|\r|\n/', trim($setting->misi ?? '')))
                    ->map(fn($baris) => trim(preg_replace('/^\s*\d+[\.\)]\s*/', '', $baris)))
                    ->filter();
            @endphp
            @if($daftarMisi->count())
                <ol class="space-y-2.5">
                    @foreach($daftarMisi as $item)
                        <li class="flex gap-3 text-desa-ink/70 leading-relaxed">
                            <span class="flex-shrink-0 w-6 h-6 rounded-full bg-desa-teal/10 text-desa-teal text-xs font-semibold flex items-center justify-center mt-0.5">{{ $loop->iteration }}</span>
                            <span>{{ $item }}</span>
                        </li>
                    @endforeach
                </ol>
            @else
                <p class="text-desa-ink/70 leading-relaxed">-</p>
            @endif
        </div>
    </div>

    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
        <div class="bg-desa-teal-dark/[0.04] border border-desa-line rounded-xl p-5">
            <p class="text-xs text-desa-ink/50 mb-1">Luas Wilayah</p>
            <p class="font-display font-semibold text-lg text-desa-teal-dark">{{ $setting->luas_wilayah_km2 ?? '-' }} km&sup2;</p>
        </div>
        <div class="bg-desa-teal-dark/[0.04] border border-desa-line rounded-xl p-5">
            <p class="text-xs text-desa-ink/50 mb-1">Kecamatan</p>
            <p class="font-display font-semibold text-lg text-desa-teal-dark">{{ $setting->kecamatan ?? '-' }}</p>
        </div>
        <div class="bg-desa-teal-dark/[0.04] border border-desa-line rounded-xl p-5">
            <p class="text-xs text-desa-ink/50 mb-1">Kabupaten</p>
            <p class="font-display font-semibold text-lg text-desa-teal-dark">{{ $setting->kabupaten ?? '-' }}</p>
        </div>
        <div class="bg-desa-teal-dark/[0.04] border border-desa-line rounded-xl p-5">
            <p class="text-xs text-desa-ink/50 mb-1">Provinsi</p>
            <p class="font-display font-semibold text-lg text-desa-teal-dark">{{ $setting->provinsi ?? '-' }}</p>
        </div>
    </div>
</div>
@endsection