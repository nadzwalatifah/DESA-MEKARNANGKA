@extends('layouts.app')

@section('title', $article->judul.' - '.($setting->nama_desa ?? ''))

@section('content')
<article class="max-w-3xl mx-auto px-4 py-16">
    <a href="{{ route('artikel.index') }}" class="inline-flex items-center gap-1.5 text-sm font-medium text-desa-ink/55 hover:text-desa-teal-dark transition mb-4">
        <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
            <path stroke-linecap="round" stroke-linejoin="round" d="M10.5 19.5 3 12m0 0 7.5-7.5M3 12h18" />
        </svg>
        Kembali ke Berita
    </a>

    <div>
        <span class="inline-block text-[11px] font-semibold uppercase tracking-wide text-desa-teal-dark bg-desa-teal-dark/[0.06] px-2.5 py-1 rounded-full">{{ $article->kategori }}</span>
    </div>
    <h1 class="font-display text-3xl md:text-4xl font-semibold mt-4 mb-3 leading-tight">{{ $article->judul }}</h1>
    <p class="text-sm text-desa-ink/45 mb-8">
        {{ $article->published_at?->translatedFormat('d F Y') }} &middot; {{ $article->dilihat }}x dilihat
    </p>

    @if($article->gambar)
        <img src="{{ asset('storage/'.$article->gambar) }}" class="w-full rounded-xl mb-8 object-cover max-h-96 border border-desa-line">
    @endif

    <div class="prose max-w-none text-desa-ink/80 leading-relaxed">
        {!! nl2br(e($article->konten)) !!}
    </div>
</article>

@if($lainnya->isNotEmpty())
<div class="max-w-6xl mx-auto px-4 pb-20">
    <div class="h-px bg-desa-line mb-10"></div>
    <h2 class="font-display text-xl font-semibold mb-6">Berita Lainnya</h2>
    <div class="grid md:grid-cols-3 gap-6">
        @foreach($lainnya as $l)
            <a href="{{ route('artikel.show', $l) }}" class="block bg-white rounded-xl border border-desa-line shadow-sm hover:shadow-md transition overflow-hidden">
                @if($l->gambar)
                    <img src="{{ asset('storage/'.$l->gambar) }}" class="w-full h-40 object-cover" alt="{{ $l->judul }}">
                @else
                    <div class="w-full h-40 bg-desa-teal-dark/[0.06] flex items-center justify-center">
                        <svg class="w-8 h-8 text-desa-ink/20" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909M3 3h18v18H3V3z" />
                        </svg>
                    </div>
                @endif
                <div class="p-5">
                    <h3 class="font-display font-semibold leading-snug line-clamp-2">{{ $l->judul }}</h3>
                    <p class="text-xs text-desa-ink/45 mt-3">{{ $l->published_at?->translatedFormat('d F Y') }}</p>
                </div>
            </a>
        @endforeach
    </div>
</div>
@endif
@endsection
