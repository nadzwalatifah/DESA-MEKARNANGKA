@extends('layouts.app')

@section('content')
<div class="max-w-6xl mx-auto px-4 py-16">
    <span class="text-[11px] font-semibold uppercase tracking-[0.18em] text-desa-teal">Kabar Desa</span>
    <h1 class="font-display text-3xl md:text-4xl font-semibold mt-2 mb-10">Berita &amp; Pengumuman</h1>

    <div class="grid md:grid-cols-3 gap-6">
        @forelse($artikel as $a)
            <a href="{{ route('artikel.show', $a) }}" class="group block bg-white rounded-xl border border-desa-line shadow-sm hover:shadow-lg hover:-translate-y-0.5 transition overflow-hidden">
                <div class="h-44 bg-desa-teal-dark/10 overflow-hidden">
                    @if($a->gambar)
                        <img src="{{ asset('storage/'.$a->gambar) }}" class="w-full h-full object-cover group-hover:scale-105 transition duration-300">
                    @endif
                </div>
                <div class="p-5">
                    <span class="inline-block text-[11px] font-semibold uppercase tracking-wide text-desa-teal-dark bg-desa-teal-dark/[0.06] px-2.5 py-1 rounded-full">{{ $a->kategori }}</span>
                    <h3 class="font-display font-semibold mt-3 leading-snug line-clamp-2">{{ $a->judul }}</h3>
                    <p class="text-xs text-desa-ink/45 mt-3">{{ $a->published_at?->translatedFormat('d F Y') }}</p>
                </div>
            </a>
        @empty
            <p class="text-desa-ink/40 col-span-full text-center py-10">Belum ada berita.</p>
        @endforelse
    </div>

    <div class="mt-10">
        {{ $artikel->links() }}
    </div>
</div>
@endsection
