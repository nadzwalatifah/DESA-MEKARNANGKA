@extends('layouts.admin')

@section('content')
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-2xl font-bold">Statistik Penduduk</h1>
        <a href="{{ route('admin.population-stats.create') }}" class="bg-green-700 text-white px-4 py-2 rounded-lg text-sm">+ Tambah Data</a>
    </div>

    <div class="bg-white rounded-xl shadow overflow-x-auto">
        <table class="w-full text-sm text-left">
            <thead class="bg-gray-100">
                <tr>
                    <th class="px-4 py-3">Tahun</th>
                    <th class="px-4 py-3">Dusun</th>
                    <th class="px-4 py-3">KK</th>
                    <th class="px-4 py-3">Laki-laki</th>
                    <th class="px-4 py-3">Perempuan</th>
                    <th class="px-4 py-3">0-15 th</th>
                    <th class="px-4 py-3">16-55 th</th>
                    <th class="px-4 py-3">&gt;55 th</th>
                    <th class="px-4 py-3 text-right">Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($stats as $s)
                    <tr class="border-b">
                        <td class="px-4 py-3">{{ $s->tahun }}</td>
                        <td class="px-4 py-3">{{ $s->dusun }}</td>
                        <td class="px-4 py-3">{{ $s->jumlah_kk }}</td>
                        <td class="px-4 py-3">{{ $s->laki_laki }}</td>
                        <td class="px-4 py-3">{{ $s->perempuan }}</td>
                        <td class="px-4 py-3">{{ $s->usia_0_15 }}</td>
                        <td class="px-4 py-3">{{ $s->usia_16_55 }}</td>
                        <td class="px-4 py-3">{{ $s->usia_diatas_55 }}</td>
                        <td class="px-4 py-3 text-right space-x-2">
                            <a href="{{ route('admin.population-stats.edit', $s) }}" class="text-blue-600 hover:underline">Edit</a>
                            <form method="POST" action="{{ route('admin.population-stats.destroy', $s) }}" class="inline" onsubmit="return confirm('Hapus data ini?')">
                                @csrf @method('DELETE')
                                <button class="text-red-600 hover:underline">Hapus</button>
                            </form>
                        </td>
                    </tr>
                @empty
                    <tr><td colspan="9" class="px-4 py-6 text-center text-gray-400">Belum ada data statistik.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>

    <p class="text-xs text-gray-400 mt-3">Gunakan dusun "Total" untuk baris rekap keseluruhan tahun tersebut, agar tampil di halaman beranda.</p>
@endsection
