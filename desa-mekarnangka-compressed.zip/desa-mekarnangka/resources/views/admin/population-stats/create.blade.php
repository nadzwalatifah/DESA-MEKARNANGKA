@extends('layouts.admin')

@section('content')
    <h1 class="text-2xl font-bold mb-6">Tambah Data Statistik</h1>

    <form method="POST" action="{{ route('admin.population-stats.store') }}" class="bg-white rounded-xl shadow p-6 space-y-4 max-w-2xl">
        @csrf
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium mb-1">Dusun</label>
                <input type="text" name="dusun" value="{{ old('dusun') }}" placeholder="Dusun 1, RW 01, atau Total" class="w-full border rounded-lg px-3 py-2" required>
                @error('dusun') <p class="text-red-500 text-xs mt-1">{{ $message }}</p> @enderror
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Tahun</label>
                <input type="number" name="tahun" value="{{ old('tahun', date('Y')) }}" class="w-full border rounded-lg px-3 py-2" required>
                @error('tahun') <p class="text-red-500 text-xs mt-1">{{ $message }}</p> @enderror
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Jumlah KK</label>
                <input type="number" name="jumlah_kk" value="{{ old('jumlah_kk', 0) }}" min="0" class="w-full border rounded-lg px-3 py-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Laki-laki</label>
                <input type="number" name="laki_laki" value="{{ old('laki_laki', 0) }}" min="0" class="w-full border rounded-lg px-3 py-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Perempuan</label>
                <input type="number" name="perempuan" value="{{ old('perempuan', 0) }}" min="0" class="w-full border rounded-lg px-3 py-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Usia 0-15 tahun</label>
                <input type="number" name="usia_0_15" value="{{ old('usia_0_15', 0) }}" min="0" class="w-full border rounded-lg px-3 py-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Usia 16-55 tahun</label>
                <input type="number" name="usia_16_55" value="{{ old('usia_16_55', 0) }}" min="0" class="w-full border rounded-lg px-3 py-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Usia diatas 55 tahun</label>
                <input type="number" name="usia_diatas_55" value="{{ old('usia_diatas_55', 0) }}" min="0" class="w-full border rounded-lg px-3 py-2">
            </div>
        </div>
        <div class="flex gap-3">
            <button class="bg-green-700 text-white px-5 py-2 rounded-lg">Simpan</button>
            <a href="{{ route('admin.population-stats.index') }}" class="px-5 py-2 rounded-lg border">Batal</a>
        </div>
    </form>
@endsection
