@extends('layouts.admin')

@section('content')
    <h1 class="text-2xl font-bold mb-6">Tambah Perangkat Desa</h1>

    <form method="POST" action="{{ route('admin.officials.store') }}" enctype="multipart/form-data" class="bg-white rounded-xl shadow p-6 space-y-4 max-w-2xl">
        @csrf
        <div>
            <label class="block text-sm font-medium mb-1">Nama</label>
            <input type="text" name="nama" value="{{ old('nama') }}" class="w-full border rounded-lg px-3 py-2" required>
            @error('nama') <p class="text-red-500 text-xs mt-1">{{ $message }}</p> @enderror
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Jabatan</label>
            <input type="text" name="jabatan" value="{{ old('jabatan') }}" placeholder="Kepala Desa, Sekretaris Desa, Kaur Keuangan, dll" class="w-full border rounded-lg px-3 py-2" required>
            @error('jabatan') <p class="text-red-500 text-xs mt-1">{{ $message }}</p> @enderror
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Deskripsi</label>
            <textarea name="deskripsi" rows="3" class="w-full border rounded-lg px-3 py-2">{{ old('deskripsi') }}</textarea>
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Urutan Tampil</label>
            <input type="number" name="urutan" value="{{ old('urutan', 0) }}" min="0" class="w-full border rounded-lg px-3 py-2">
            <p class="text-xs text-gray-400 mt-1">Angka lebih kecil tampil lebih dulu di struktur organisasi.</p>
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Foto</label>
            <input type="file" name="foto" class="w-full border rounded-lg px-3 py-2">
            @error('foto') <p class="text-red-500 text-xs mt-1">{{ $message }}</p> @enderror
        </div>
        <div class="flex gap-3">
            <button class="bg-green-700 text-white px-5 py-2 rounded-lg">Simpan</button>
            <a href="{{ route('admin.officials.index') }}" class="px-5 py-2 rounded-lg border">Batal</a>
        </div>
    </form>
@endsection
