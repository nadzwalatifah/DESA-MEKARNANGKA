@extends('layouts.admin')

@section('content')
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-2xl font-bold">Struktur Organisasi</h1>
        <a href="{{ route('admin.officials.create') }}" class="bg-green-700 text-white px-4 py-2 rounded-lg text-sm">+ Tambah Pejabat</a>
    </div>

    <div class="bg-white rounded-xl shadow overflow-x-auto">
        <table class="w-full text-sm text-left">
            <thead class="bg-gray-100">
                <tr>
                    <th class="px-4 py-3">Foto</th>
                    <th class="px-4 py-3">Nama</th>
                    <th class="px-4 py-3">Jabatan</th>
                    <th class="px-4 py-3">Urutan</th>
                    <th class="px-4 py-3 text-right">Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($pejabat as $p)
                    <tr class="border-b">
                        <td class="px-4 py-3">
                            @if($p->foto)
                                <img src="{{ Storage::url($p->foto) }}" class="w-10 h-10 object-cover rounded-full">
                            @else
                                <div class="w-10 h-10 rounded-full bg-gray-200"></div>
                            @endif
                        </td>
                        <td class="px-4 py-3">{{ $p->nama }}</td>
                        <td class="px-4 py-3">{{ $p->jabatan }}</td>
                        <td class="px-4 py-3">{{ $p->urutan }}</td>
                        <td class="px-4 py-3 text-right space-x-2">
                            <a href="{{ route('admin.officials.edit', $p) }}" class="text-blue-600 hover:underline">Edit</a>
                            <form method="POST" action="{{ route('admin.officials.destroy', $p) }}" class="inline" onsubmit="return confirm('Hapus data ini?')">
                                @csrf @method('DELETE')
                                <button class="text-red-600 hover:underline">Hapus</button>
                            </form>
                        </td>
                    </tr>
                @empty
                    <tr><td colspan="5" class="px-4 py-6 text-center text-gray-400">Belum ada data perangkat desa.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
@endsection
