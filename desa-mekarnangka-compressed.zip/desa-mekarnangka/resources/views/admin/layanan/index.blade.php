@extends('layouts.admin')

@section('content')
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-2xl font-bold">Layanan</h1>
        <a href="{{ route('admin.layanan.create') }}" class="bg-green-700 text-white px-4 py-2 rounded-lg text-sm">+ Tambah Layanan</a>
    </div>

    @if(session('status'))
        <div class="bg-green-100 text-green-800 px-4 py-3 rounded-lg mb-4 text-sm">{{ session('status') }}</div>
    @endif

    <div class="bg-white rounded-xl shadow overflow-x-auto">
        <table class="w-full text-sm text-left">
            <thead class="bg-gray-100">
                <tr>
                    <th class="px-4 py-3">Foto</th>
                    <th class="px-4 py-3">Urutan</th>
                    <th class="px-4 py-3">Judul</th>
                    <th class="px-4 py-3">Deskripsi Singkat</th>
                    <th class="px-4 py-3">Status</th>
                    <th class="px-4 py-3 text-right">Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($layanan as $l)
                    <tr class="border-b">
                        <td class="px-4 py-3">
                            @if($l->foto)
                                <img src="{{ asset('storage/' . $l->foto) }}" alt="{{ $l->judul }}" class="w-14 h-10 object-cover rounded">
                            @else
                                <span class="text-gray-300 text-xs">-</span>
                            @endif
                        </td>
                        <td class="px-4 py-3">{{ $l->urutan }}</td>
                        <td class="px-4 py-3 font-medium">{{ $l->judul }}</td>
                        <td class="px-4 py-3 text-gray-500">{{ Str::limit($l->deskripsi_singkat, 60) }}</td>
                        <td class="px-4 py-3">
                            @if($l->is_aktif)
                                <span class="text-green-700 font-medium">Aktif</span>
                            @else
                                <span class="text-gray-400">Nonaktif</span>
                            @endif
                        </td>
                        <td class="px-4 py-3 text-right space-x-2">
                            <a href="{{ route('admin.layanan.edit', $l) }}" class="text-blue-600 hover:underline">Edit</a>
                            <form method="POST" action="{{ route('admin.layanan.destroy', $l) }}" class="inline" onsubmit="return confirm('Hapus layanan ini?')">
                                @csrf @method('DELETE')
                                <button class="text-red-600 hover:underline">Hapus</button>
                            </form>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="6" class="px-4 py-6 text-center text-gray-400">Belum ada layanan. Tambahkan yang pertama.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    <div class="mt-6">{{ $layanan->links() }}</div>
@endsection
