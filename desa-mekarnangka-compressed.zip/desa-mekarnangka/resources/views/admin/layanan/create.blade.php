@extends('layouts.admin')

@section('content')
    <h1 class="text-2xl font-bold mb-6">Tambah Layanan</h1>

    <form method="POST" action="{{ route('admin.layanan.store') }}" enctype="multipart/form-data" class="bg-white rounded-xl shadow p-6 space-y-4 max-w-2xl">
        @csrf
        <div>
            <label class="block text-sm font-medium mb-1">Judul</label>
            <input type="text" name="judul" value="{{ old('judul') }}" class="w-full border rounded-lg px-3 py-2" required>
            @error('judul') <p class="text-red-500 text-xs mt-1">{{ $message }}</p> @enderror
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Deskripsi Singkat</label>
            <p class="text-xs text-gray-400 mb-1">Tampil di card daftar layanan pada halaman publik "Layanan".</p>
            <textarea name="deskripsi_singkat" rows="2" class="w-full border rounded-lg px-3 py-2" required>{{ old('deskripsi_singkat') }}</textarea>
            @error('deskripsi_singkat') <p class="text-red-500 text-xs mt-1">{{ $message }}</p> @enderror
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Deskripsi Lengkap</label>
            <p class="text-xs text-gray-400 mb-1">Tampil di jendela "Baca selengkapnya" (syarat, prosedur, dll).</p>
            <textarea name="deskripsi_lengkap" rows="6" class="w-full border rounded-lg px-3 py-2">{{ old('deskripsi_lengkap') }}</textarea>
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Foto</label>
            <p class="text-xs text-gray-400 mb-1">Ditampilkan di card layanan pada halaman publik. Maks 2MB.</p>
            <input type="file" name="foto" accept="image/*" class="w-full border rounded-lg px-3 py-2">
            @error('foto') <p class="text-red-500 text-xs mt-1">{{ $message }}</p> @enderror
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">URL Embed Google Maps</label>
            <input type="text" name="maps_embed_url" value="{{ old('maps_embed_url') }}" placeholder="https://www.google.com/maps/embed?pb=..." class="w-full border rounded-lg px-3 py-2">
            <p class="text-xs text-gray-400 mt-1">
                Ambil dari Google Maps: cari lokasi → <strong>Bagikan</strong> → <strong>Sematkan peta (Embed a map)</strong> → salin bagian <code>src="..."</code> saja. Link share biasa (maps.app.goo.gl atau google.com/maps/place/...) tidak akan diterima karena Google memblokir link tersebut untuk ditampilkan sebagai iframe.
            </p>
            @error('maps_embed_url') <p class="text-red-500 text-xs mt-1">{{ $message }}</p> @enderror
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Nomor Telepon</label>
            <p class="text-xs text-gray-400 mb-1">Akan ditampilkan sebagai tautan yang bisa langsung ditekan/telepon di halaman publik.</p>
            <input type="text" name="nomor_telepon" value="{{ old('nomor_telepon') }}" placeholder="08xxxxxxxxxx" class="w-full border rounded-lg px-3 py-2">
            @error('nomor_telepon') <p class="text-red-500 text-xs mt-1">{{ $message }}</p> @enderror
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Urutan</label>
            <input type="number" name="urutan" value="{{ old('urutan', 0) }}" min="0" class="w-32 border rounded-lg px-3 py-2">
        </div>
        <div class="flex items-center gap-2">
            <input type="checkbox" name="is_aktif" value="1" id="is_aktif" checked>
            <label for="is_aktif" class="text-sm">Tampilkan di halaman Layanan</label>
        </div>
        <div class="flex gap-3">
            <button class="bg-green-700 text-white px-5 py-2 rounded-lg">Simpan</button>
            <a href="{{ route('admin.layanan.index') }}" class="px-5 py-2 rounded-lg border">Batal</a>
        </div>
    </form>
@endsection
