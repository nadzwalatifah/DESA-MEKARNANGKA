@extends('layouts.admin')

@section('content')
    <h1 class="text-2xl font-bold mb-6">Dashboard</h1>
    <div class="grid grid-cols-1 sm:grid-cols-3 gap-6">
        <div class="bg-white rounded-xl shadow p-6">
            <p class="text-3xl font-bold text-green-700">{{ $totalArtikel }}</p>
            <p class="text-sm text-gray-500 mt-1">Total Berita</p>
        </div>
        <div class="bg-white rounded-xl shadow p-6">
            <p class="text-3xl font-bold text-green-700">{{ $totalGaleri }}</p>
            <p class="text-sm text-gray-500 mt-1">Total Foto Galeri</p>
        </div>
        <div class="bg-white rounded-xl shadow p-6">
            <p class="text-3xl font-bold text-green-700">{{ $totalPejabat }}</p>
            <p class="text-sm text-gray-500 mt-1">Perangkat Desa</p>
        </div>
    </div>
@endsection
