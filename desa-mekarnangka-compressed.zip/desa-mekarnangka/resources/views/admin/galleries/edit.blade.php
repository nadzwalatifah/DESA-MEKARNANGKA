@extends('layouts.admin')

@section('content')
    <h1 class="text-2xl font-bold mb-6">Edit Foto Galeri</h1>

    <form method="POST" action="{{ route('admin.galleries.update', $gallery) }}" enctype="multipart/form-data" class="bg-white rounded-xl shadow p-6 space-y-4 max-w-2xl">
        @csrf
        @method('PUT')
        <div>
            <label class="block text-sm font-medium mb-1">Judul</label>
            <input type="text" name="judul" value="{{ old('judul', $gallery->judul) }}" class="w-full border rounded-lg px-3 py-2" required>
            @error('judul') <p class="text-red-500 text-xs mt-1">{{ $message }}</p> @enderror
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Deskripsi</label>
            <textarea name="deskripsi" rows="3" class="w-full border rounded-lg px-3 py-2">{{ old('deskripsi', $gallery->deskripsi) }}</textarea>
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Urutan Tampil</label>
            <input type="number" name="urutan" value="{{ old('urutan', $gallery->urutan) }}" min="0" class="w-full border rounded-lg px-3 py-2">
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Foto</label>
            @if($gallery->foto)
                <img src="{{ Storage::url($gallery->foto) }}" class="w-24 h-24 object-cover rounded-lg mb-2">
            @endif
            <input type="file" name="foto" class="w-full border rounded-lg px-3 py-2">
            <p class="text-xs text-gray-400 mt-1">Kosongkan jika tidak ingin mengganti foto.</p>
            @error('foto') <p class="text-red-500 text-xs mt-1">{{ $message }}</p> @enderror
        </div>
        <div class="flex gap-3">
            <button class="bg-green-700 text-white px-5 py-2 rounded-lg">Simpan</button>
            <a href="{{ route('admin.galleries.index') }}" class="px-5 py-2 rounded-lg border">Batal</a>
        </div>
    </form>
@endsection
