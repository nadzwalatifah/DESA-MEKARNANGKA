@extends('layouts.admin')

@section('content')
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-2xl font-bold">Galeri</h1>
        <a href="{{ route('admin.galleries.create') }}" class="bg-green-700 text-white px-4 py-2 rounded-lg text-sm">+ Tambah Foto</a>
    </div>

    <div class="bg-white rounded-xl shadow overflow-x-auto">
        <table class="w-full text-sm text-left">
            <thead class="bg-gray-100">
                <tr>
                    <th class="px-4 py-3">Foto</th>
                    <th class="px-4 py-3">Judul</th>
                    <th class="px-4 py-3">Urutan</th>
                    <th class="px-4 py-3 text-right">Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($galleries as $g)
                    <tr class="border-b">
                        <td class="px-4 py-3">
                            <img src="{{ Storage::url($g->foto) }}" class="w-14 h-14 object-cover rounded-lg">
                        </td>
                        <td class="px-4 py-3">{{ $g->judul }}</td>
                        <td class="px-4 py-3">{{ $g->urutan }}</td>
                        <td class="px-4 py-3 text-right space-x-2">
                            <a href="{{ route('admin.galleries.edit', $g) }}" class="text-blue-600 hover:underline">Edit</a>
                            <form method="POST" action="{{ route('admin.galleries.destroy', $g) }}" class="inline" onsubmit="return confirm('Hapus foto ini?')">
                                @csrf @method('DELETE')
                                <button class="text-red-600 hover:underline">Hapus</button>
                            </form>
                        </td>
                    </tr>
                @empty
                    <tr><td colspan="4" class="px-4 py-6 text-center text-gray-400">Belum ada foto di galeri.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
@endsection
