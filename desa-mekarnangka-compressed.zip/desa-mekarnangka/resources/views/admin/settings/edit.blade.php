@extends('layouts.admin')

@section('content')
    <h1 class="text-2xl font-bold mb-6">Pengaturan Profil Desa</h1>

    <form method="POST" action="{{ route('admin.settings.update') }}" enctype="multipart/form-data" class="bg-white rounded-xl shadow p-6 space-y-4 max-w-3xl">
        @csrf
        @method('PUT')

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium mb-1">Nama Desa</label>
                <input type="text" name="nama_desa" value="{{ old('nama_desa', $setting->nama_desa) }}" class="w-full border rounded-lg px-3 py-2" required>
                @error('nama_desa') <p class="text-red-500 text-xs mt-1">{{ $message }}</p> @enderror
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Nama Kepala Desa</label>
                <input type="text" name="nama_kepala_desa" value="{{ old('nama_kepala_desa', $setting->nama_kepala_desa) }}" class="w-full border rounded-lg px-3 py-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Kecamatan</label>
                <input type="text" name="kecamatan" value="{{ old('kecamatan', $setting->kecamatan) }}" class="w-full border rounded-lg px-3 py-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Kabupaten</label>
                <input type="text" name="kabupaten" value="{{ old('kabupaten', $setting->kabupaten) }}" class="w-full border rounded-lg px-3 py-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Provinsi</label>
                <input type="text" name="provinsi" value="{{ old('provinsi', $setting->provinsi) }}" class="w-full border rounded-lg px-3 py-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Kode Pos</label>
                <input type="text" name="kode_pos" value="{{ old('kode_pos', $setting->kode_pos) }}" class="w-full border rounded-lg px-3 py-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Telepon</label>
                <input type="text" name="telepon" value="{{ old('telepon', $setting->telepon) }}" class="w-full border rounded-lg px-3 py-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Email</label>
                <input type="email" name="email" value="{{ old('email', $setting->email) }}" class="w-full border rounded-lg px-3 py-2">
                @error('email') <p class="text-red-500 text-xs mt-1">{{ $message }}</p> @enderror
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Luas Wilayah (km²)</label>
                <input type="number" step="0.01" name="luas_wilayah_km2" value="{{ old('luas_wilayah_km2', $setting->luas_wilayah_km2) }}" class="w-full border rounded-lg px-3 py-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">URL Embed Google Maps</label>
                <input type="text" name="maps_embed_url" value="{{ old('maps_embed_url', $setting->maps_embed_url) }}" placeholder="https://www.google.com/maps/embed?pb=..." class="w-full border rounded-lg px-3 py-2">
                <p class="text-xs text-gray-400 mt-1">
                    Ambil dari Google Maps: cari lokasi → <strong>Bagikan</strong> → <strong>Sematkan peta (Embed a map)</strong> → salin bagian <code>src="..."</code> saja. Link share biasa (maps.app.goo.gl atau google.com/maps/place/...) tidak akan diterima karena Google memblokir link tersebut untuk ditampilkan sebagai iframe.
                </p>
                @error('maps_embed_url') <p class="text-red-500 text-xs mt-1">{{ $message }}</p> @enderror
            </div>
        </div>

        <div>
            <label class="block text-sm font-medium mb-1">Alamat Kantor Desa</label>
            <textarea name="alamat_kantor" rows="2" class="w-full border rounded-lg px-3 py-2">{{ old('alamat_kantor', $setting->alamat_kantor) }}</textarea>
        </div>

        <div>
            <label class="block text-sm font-medium mb-1">Sambutan Kepala Desa</label>
            <textarea name="sambutan_kepala_desa" rows="4" class="w-full border rounded-lg px-3 py-2">{{ old('sambutan_kepala_desa', $setting->sambutan_kepala_desa) }}</textarea>
        </div>

        <div>
            <label class="block text-sm font-medium mb-1">Visi</label>
            <textarea name="visi" rows="2" class="w-full border rounded-lg px-3 py-2">{{ old('visi', $setting->visi) }}</textarea>
        </div>

        <div>
            <label class="block text-sm font-medium mb-1">Misi</label>
            <textarea name="misi" rows="4" class="w-full border rounded-lg px-3 py-2">{{ old('misi', $setting->misi) }}</textarea>
        </div>

        <div>
            <label class="block text-sm font-medium mb-1">Sejarah Desa</label>
            <textarea name="sejarah" rows="5" class="w-full border rounded-lg px-3 py-2">{{ old('sejarah', $setting->sejarah) }}</textarea>
        </div>

        <hr class="border-gray-200">
        <h2 class="text-lg font-semibold">Struktur Organisasi — BPD & Lembaga Kemasyarakatan</h2>
        <p class="text-xs text-gray-400 -mt-2">Kotak-kotak ini akan tampil di sebelah Kepala Desa pada halaman Struktur Organisasi (garis putus-putus). Kosongkan jika tidak ingin ditampilkan.</p>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium mb-1">Nama Ketua BPD</label>
                <input type="text" name="nama_ketua_bpd" value="{{ old('nama_ketua_bpd', $setting->nama_ketua_bpd) }}" class="w-full border rounded-lg px-3 py-2">
                @error('nama_ketua_bpd') <p class="text-red-500 text-xs mt-1">{{ $message }}</p> @enderror
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Foto Ketua BPD</label>
                @if($setting->foto_ketua_bpd)
                    <img src="{{ Storage::url($setting->foto_ketua_bpd) }}" class="w-16 h-16 object-cover rounded-lg mb-2">
                @endif
                <input type="file" name="foto_ketua_bpd" class="w-full border rounded-lg px-3 py-2">
                @error('foto_ketua_bpd') <p class="text-red-500 text-xs mt-1">{{ $message }}</p> @enderror
            </div>
        </div>

        <div>
            <label class="block text-sm font-medium mb-1">Daftar Lembaga Kemasyarakatan</label>
            <textarea name="lembaga_kemasyarakatan" rows="6" placeholder="LPMD&#10;TP PKK&#10;Karang Taruna&#10;RT/RW&#10;MUI Desa&#10;Linmas&#10;Babinmas&#10;Babinsa" class="w-full border rounded-lg px-3 py-2">{{ old('lembaga_kemasyarakatan', $setting->lembaga_kemasyarakatan) }}</textarea>
            <p class="text-xs text-gray-400 mt-1">Satu lembaga per baris.</p>
            @error('lembaga_kemasyarakatan') <p class="text-red-500 text-xs mt-1">{{ $message }}</p> @enderror
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium mb-1">Foto Kepala Desa</label>
                @if($setting->foto_kepala_desa)
                    <img src="{{ Storage::url($setting->foto_kepala_desa) }}" class="w-24 h-24 object-cover rounded-lg mb-2">
                @endif
                <input type="file" name="foto_kepala_desa" class="w-full border rounded-lg px-3 py-2">
                @error('foto_kepala_desa') <p class="text-red-500 text-xs mt-1">{{ $message }}</p> @enderror
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Video Sambutan Kepala Desa</label>
                @if($setting->video_kepala_desa)
                    <video src="{{ Storage::url($setting->video_kepala_desa) }}" controls class="w-full rounded-lg mb-2 max-w-xs"></video>
                @endif
                <input type="file" name="video_kepala_desa" accept="video/mp4,video/webm,video/quicktime" class="w-full border rounded-lg px-3 py-2">
                <p class="text-xs text-gray-400 mt-1">Format MP4/WebM/MOV, maksimal 50MB. Kosongkan jika tidak ingin mengubah video.</p>
                @error('video_kepala_desa') <p class="text-red-500 text-xs mt-1">{{ $message }}</p> @enderror
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Logo Desa</label>
                @if($setting->logo)
                    <img src="{{ Storage::url($setting->logo) }}" class="w-24 h-24 object-cover rounded-lg mb-2">
                @endif
                <input type="file" name="logo" class="w-full border rounded-lg px-3 py-2">
                @error('logo') <p class="text-red-500 text-xs mt-1">{{ $message }}</p> @enderror
            </div>
        </div>

        <div class="flex gap-3 pt-2">
            <button class="bg-green-700 text-white px-5 py-2 rounded-lg">Simpan</button>
        </div>
    </form>
@endsection