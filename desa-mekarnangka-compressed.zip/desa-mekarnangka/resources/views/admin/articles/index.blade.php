@extends('layouts.admin')

@section('content')
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-2xl font-bold">Berita</h1>
        <a href="{{ route('admin.articles.create') }}" class="bg-green-700 text-white px-4 py-2 rounded-lg text-sm">+ Tambah Berita</a>
    </div>

    <div class="bg-white rounded-xl shadow overflow-x-auto">
        <table class="w-full text-sm text-left">
            <thead class="bg-gray-100">
                <tr>
                    <th class="px-4 py-3">Judul</th>
                    <th class="px-4 py-3">Kategori</th>
                    <th class="px-4 py-3">Status</th>
                    <th class="px-4 py-3">Dilihat</th>
                    <th class="px-4 py-3 text-right">Aksi</th>
                </tr>
            </thead>
            <tbody>
                @foreach($artikel as $a)
                    <tr class="border-b">
                        <td class="px-4 py-3">{{ $a->judul }}</td>
                        <td class="px-4 py-3">{{ $a->kategori }}</td>
                        <td class="px-4 py-3">
                            @if($a->is_published)
                                <span class="text-green-700 font-medium">Terbit</span>
                            @else
                                <span class="text-gray-400">Draft</span>
                            @endif
                        </td>
                        <td class="px-4 py-3">{{ $a->dilihat }}</td>
                        <td class="px-4 py-3 text-right space-x-2">
                            <a href="{{ route('admin.articles.edit', $a) }}" class="text-blue-600 hover:underline">Edit</a>
                            <form method="POST" action="{{ route('admin.articles.destroy', $a) }}" class="inline" onsubmit="return confirm('Hapus artikel ini?')">
                                @csrf @method('DELETE')
                                <button class="text-red-600 hover:underline">Hapus</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>

    <div class="mt-6">{{ $artikel->links() }}</div>
@endsection
