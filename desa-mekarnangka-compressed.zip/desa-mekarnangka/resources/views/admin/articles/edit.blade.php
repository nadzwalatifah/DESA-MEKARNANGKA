@extends('layouts.admin')

@section('content')
    <h1 class="text-2xl font-bold mb-6">Edit Berita</h1>

    <form method="POST" action="{{ route('admin.articles.update', $article) }}" enctype="multipart/form-data" class="bg-white rounded-xl shadow p-6 space-y-4 max-w-2xl">
        @csrf @method('PUT')
        <div>
            <label class="block text-sm font-medium mb-1">Judul</label>
            <input type="text" name="judul" value="{{ old('judul', $article->judul) }}" class="w-full border rounded-lg px-3 py-2" required>
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Kategori</label>
            <select name="kategori" class="w-full border rounded-lg px-3 py-2">
                @foreach(['Berita', 'Pengumuman', 'Kegiatan'] as $kat)
                    <option {{ $article->kategori === $kat ? 'selected' : '' }}>{{ $kat }}</option>
                @endforeach
            </select>
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Ringkasan</label>
            <textarea name="ringkasan" rows="2" class="w-full border rounded-lg px-3 py-2">{{ old('ringkasan', $article->ringkasan) }}</textarea>
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Konten</label>
            <textarea name="konten" rows="8" class="w-full border rounded-lg px-3 py-2" required>{{ old('konten', $article->konten) }}</textarea>
        </div>
        @if($article->gambar)
            <img src="{{ asset('storage/'.$article->gambar) }}" class="h-32 rounded-lg">
        @endif
        <div>
            <label class="block text-sm font-medium mb-1">Ganti Gambar</label>
            <input type="file" name="gambar" class="w-full border rounded-lg px-3 py-2">
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Tanggal Terbit</label>
            <input type="date" name="published_at" value="{{ old('published_at', ($article->published_at ?? $article->created_at)->format('Y-m-d')) }}" class="w-full border rounded-lg px-3 py-2">
            <p class="text-xs text-gray-400 mt-1">Otomatis terisi sesuai tanggal dibuat, ubah jika perlu.</p>
            @error('published_at') <p class="text-red-500 text-xs mt-1">{{ $message }}</p> @enderror
        </div>
        <div class="flex items-center gap-2">
            <input type="checkbox" name="is_published" value="1" id="is_published" {{ $article->is_published ? 'checked' : '' }}>
            <label for="is_published" class="text-sm">Terbitkan</label>
        </div>
        <div class="flex gap-3">
            <button class="bg-green-700 text-white px-5 py-2 rounded-lg">Simpan Perubahan</button>
            <a href="{{ route('admin.articles.index') }}" class="px-5 py-2 rounded-lg border">Batal</a>
        </div>
    </form>
@endsection
