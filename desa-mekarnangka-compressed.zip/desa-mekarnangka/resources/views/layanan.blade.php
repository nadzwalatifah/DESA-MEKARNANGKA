@extends('layouts.app')

@section('content')
<div class="max-w-6xl mx-auto px-4 py-16" style="background-color:#faf8f2; color:#1c2b27;">
    <span class="text-[11px] font-semibold uppercase tracking-[0.18em]" style="color:#1f6f63;">Pelayanan Publik</span>
    <h1 class="font-display text-3xl md:text-4xl font-semibold mt-2 mb-2" style="color:#1c2b27;">Layanan {{ $setting->nama_desa }}</h1>
    <p class="mb-12 max-w-2xl" style="color:rgba(28,43,39,0.6);">Berikut layanan yang tersedia bagi warga {{ $setting->nama_desa }}.</p>

    @if($layanan->isEmpty())
        <p class="text-center py-10" style="color:rgba(28,43,39,0.4);">Belum ada layanan yang ditambahkan.</p>
    @else
        <div class="grid md:grid-cols-3 gap-4 md:gap-6 items-start" x-data="{ open: null }">
            @foreach($layanan as $l)
                <div class="rounded-xl border shadow-sm overflow-hidden hover:shadow-md transition" style="background-color:#ffffff; border-color:#e7e0cd;">
                    @if($l->foto)
                        <img src="{{ asset('storage/' . $l->foto) }}" alt="{{ $l->judul }}" class="w-full h-28 md:h-40 object-cover">
                    @endif
                    <div class="p-4 md:p-6">
                        <h2 class="font-display font-semibold text-base md:text-lg mb-1.5 md:mb-2" style="color:#0f3d3b;">{{ $l->judul }}</h2>
                        <p class="text-xs md:text-sm leading-relaxed" style="color:rgba(28,43,39,0.65);">{{ $l->deskripsi_singkat }}</p>

                        @if($l->nomor_telepon)
                            <a href="tel:{{ preg_replace('/[^0-9+]/', '', $l->nomor_telepon) }}"
                               class="inline-flex items-center gap-1.5 text-xs md:text-sm font-semibold mt-2 md:mt-3 transition"
                               style="color:#1f6f63;">
                                <svg class="w-3.5 h-3.5 md:w-4 md:h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h1.5a2.25 2.25 0 0 0 2.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106a1.125 1.125 0 0 0-1.173.417l-.97 1.293a11.25 11.25 0 0 1-6.63-6.63l1.293-.97a1.125 1.125 0 0 0 .417-1.173L7.963 3.852a1.125 1.125 0 0 0-1.091-.852H5.5A2.25 2.25 0 0 0 3.25 5.25v1.5Z"/>
                                </svg>
                                {{ $l->nomor_telepon }}
                            </a>
                        @endif

                        @if($l->deskripsi_lengkap || $l->maps_embed_url)
                            <button type="button" @click="open = (open === {{ $l->id }} ? null : {{ $l->id }})"
                                    class="flex w-full items-center justify-between gap-2 text-xs md:text-sm font-semibold mt-3 md:mt-4 pt-3 md:pt-4 border-t transition"
                                    style="color:#0f3d3b; border-color:#e7e0cd;"
                                    onmouseover="this.style.color='#c9962f'" onmouseout="this.style.color='#0f3d3b'">
                                <span x-text="open === {{ $l->id }} ? 'Tutup' : 'Baca selengkapnya'"></span>
                                <svg class="w-4 h-4 md:w-5 md:h-5 shrink-0 transition-transform duration-300 ease-in-out"
                                     :class="open === {{ $l->id }} ? 'rotate-180' : 'rotate-0'"
                                     fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.25">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                                </svg>
                            </button>

                            <div x-show="open === {{ $l->id }}" x-cloak
                                 x-transition:enter="transition ease-out duration-300"
                                 x-transition:enter-start="opacity-0 -translate-y-1"
                                 x-transition:enter-end="opacity-100 translate-y-0"
                                 x-transition:leave="transition ease-in duration-200"
                                 x-transition:leave-start="opacity-100 translate-y-0"
                                 x-transition:leave-end="opacity-0 -translate-y-1">
                                @if($l->deskripsi_lengkap)
                                    <p class="text-xs md:text-sm mt-3 md:mt-4 whitespace-pre-line leading-relaxed" style="color:rgba(28,43,39,0.7);">{{ $l->deskripsi_lengkap }}</p>
                                @endif

                                @if($l->maps_embed_url)
                                    <div class="mt-3 md:mt-4 rounded-lg overflow-hidden border" style="border-color:#e7e0cd; height:160px;" x-bind:style="'border-color:#e7e0cd; height:' + (window.innerWidth >= 768 ? '220px' : '160px')">
                                        <iframe src="{{ $l->maps_embed_url }}" class="w-full h-full border-0" allowfullscreen loading="lazy"></iframe>
                                    </div>
                                @endif
                            </div>
                        @endif
                    </div>
                </div>
            @endforeach
        </div>
    @endif

    <p class="text-sm mt-12 border-t pt-6" style="color:rgba(28,43,39,0.4); border-color:#e7e0cd;">Hubungi kantor desa untuk informasi lebih lanjut mengenai persyaratan dan prosedur setiap layanan.</p>
</div>
@endsection