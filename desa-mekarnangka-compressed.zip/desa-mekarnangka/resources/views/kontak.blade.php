@extends('layouts.app')

@section('content')
<div class="max-w-5xl mx-auto px-4 py-16 grid md:grid-cols-2 gap-10">
    <div>
        <span class="text-[11px] font-semibold uppercase tracking-[0.18em] text-desa-teal">Kontak</span>
        <h1 class="font-display text-3xl md:text-4xl font-semibold mt-2 mb-8">Hubungi Kami</h1>

        <ul class="space-y-5">
            <li class="flex items-start gap-4">
                <span class="w-10 h-10 rounded-full bg-desa-teal-dark/[0.06] flex items-center justify-center text-desa-teal-dark shrink-0">
                    <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.7"><path stroke-linecap="round" stroke-linejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z"/></svg>
                </span>
                <div>
                    <p class="text-xs uppercase tracking-wide text-desa-ink/40 mb-0.5">Alamat</p>
                    <p class="text-desa-ink/80 leading-relaxed">{{ $setting->alamat_kantor ?? '-' }}</p>
                </div>
            </li>
            <li class="flex items-start gap-4">
                <span class="w-10 h-10 rounded-full bg-desa-teal-dark/[0.06] flex items-center justify-center text-desa-teal-dark shrink-0">
                    <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.7"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h1.5a2.25 2.25 0 002.25-2.25v-1.372a1.125 1.125 0 00-.852-1.09l-4.423-1.106a1.125 1.125 0 00-1.173.417l-.97 1.293a11.25 11.25 0 01-6.238-6.238l1.293-.97a1.125 1.125 0 00.417-1.173L8.963 3.852a1.125 1.125 0 00-1.09-.852H6.5A2.25 2.25 0 004.25 5.25v1.5z"/></svg>
                </span>
                <div>
                    <p class="text-xs uppercase tracking-wide text-desa-ink/40 mb-0.5">Telepon</p>
                    <p class="text-desa-ink/80">{{ $setting->telepon ?? '-' }}</p>
                </div>
            </li>
            <li class="flex items-start gap-4">
                <span class="w-10 h-10 rounded-full bg-desa-teal-dark/[0.06] flex items-center justify-center text-desa-teal-dark shrink-0">
                    <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.7"><path stroke-linecap="round" stroke-linejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.916V6.75"/></svg>
                </span>
                <div>
                    <p class="text-xs uppercase tracking-wide text-desa-ink/40 mb-0.5">Email</p>
                    <p class="text-desa-ink/80 break-all">{{ $setting->email ?? '-' }}</p>
                </div>
            </li>
            <li class="flex items-start gap-4">
                <span class="w-10 h-10 rounded-full bg-desa-teal-dark/[0.06] flex items-center justify-center text-desa-teal-dark shrink-0">
                    <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.7"><path stroke-linecap="round" stroke-linejoin="round" d="M3.75 9v10.5A2.25 2.25 0 006 21.75h12a2.25 2.25 0 002.25-2.25V9M8.25 21V12.75a1.5 1.5 0 011.5-1.5h4.5a1.5 1.5 0 011.5 1.5V21"/></svg>
                </span>
                <div>
                    <p class="text-xs uppercase tracking-wide text-desa-ink/40 mb-0.5">Kode Pos</p>
                    <p class="text-desa-ink/80">{{ $setting->kode_pos ?? '-' }}</p>
                </div>
            </li>
        </ul>
    </div>

    <div class="rounded-xl overflow-hidden border border-desa-line shadow-sm h-80 bg-desa-teal-dark/5">
        @if($setting->maps_embed_url)
            <iframe src="{{ $setting->maps_embed_url }}" class="w-full h-full border-0" allowfullscreen loading="lazy"></iframe>
        @else
            <div class="w-full h-full flex items-center justify-center text-desa-ink/40 text-sm">Peta belum diisi</div>
        @endif
    </div>
</div>
@endsection
