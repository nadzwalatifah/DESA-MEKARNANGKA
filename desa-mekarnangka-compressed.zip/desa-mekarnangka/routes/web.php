<?php

use App\Http\Controllers\ArticleController;
use App\Http\Controllers\GalleryController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\Admin\ArticleController as AdminArticleController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\GalleryController as AdminGalleryController;
use App\Http\Controllers\Admin\LayananController as AdminLayananController;
use App\Http\Controllers\Admin\OfficialController;
use App\Http\Controllers\Admin\PopulationStatController;
use App\Http\Controllers\Admin\SettingController;
use Illuminate\Support\Facades\Route;

// Sajikan file dari storage/app/public secara manual (tanpa lewat symlink).
// Ini untuk menghindari bug 403 Forbidden pada `php artisan serve` di Windows
// saat mengakses file lewat symbolic link public/storage.
Route::get('/storage/{path}', function (string $path) {
    $fullPath = storage_path('app/public/' . $path);

    abort_unless(file_exists($fullPath), 404);

    return response()->file($fullPath);
})->where('path', '.*')->name('storage.custom');

// ==== PUBLIK ====
Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/layanan', [HomeController::class, 'layanan'])->name('layanan');
Route::get('/struktur-organisasi', [HomeController::class, 'struktur'])->name('struktur');
Route::get('/statistik-penduduk', [HomeController::class, 'statistik'])->name('statistik');
Route::get('/kontak', [HomeController::class, 'kontak'])->name('kontak');

Route::get('/dashboard', function () {
    return redirect()->route('admin.dashboard');
})->middleware(['auth'])->name('dashboard');

Route::get('/berita', [ArticleController::class, 'index'])->name('artikel.index');
Route::get('/berita/{article}', [ArticleController::class, 'show'])->name('artikel.show');

Route::get('/galeri', [GalleryController::class, 'index'])->name('galeri.index');

// ==== ADMIN (perlu auth, gunakan Breeze/Jetstream untuk login) ====
Route::middleware(['auth'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/', [DashboardController::class, 'index'])->name('dashboard');
    Route::resource('articles', AdminArticleController::class);
    Route::resource('officials', OfficialController::class);
    Route::resource('population-stats', PopulationStatController::class);
    Route::get('settings', [SettingController::class, 'edit'])->name('settings.edit');
    Route::put('settings', [SettingController::class, 'update'])->name('settings.update');
    Route::resource('galleries', AdminGalleryController::class);
    Route::resource('layanan', AdminLayananController::class)->except(['show']);
});

require __DIR__.'/auth.php'; // dari Laravel Breeze
