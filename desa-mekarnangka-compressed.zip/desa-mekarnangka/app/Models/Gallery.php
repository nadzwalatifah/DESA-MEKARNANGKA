<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Gallery extends Model
{
    use HasFactory;

    protected $fillable = [
        'judul',
        'foto',
        'deskripsi',
        'urutan',
    ];

    public function scopeUrut($query)
    {
        return $query->orderBy('urutan')->orderByDesc('created_at');
    }
}
