<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PopulationStat extends Model
{
    protected $guarded = [];

    public function getTotalJiwaAttribute(): int
    {
        return $this->laki_laki + $this->perempuan;
    }
}
