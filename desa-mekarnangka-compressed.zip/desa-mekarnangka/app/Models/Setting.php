<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Setting extends Model
{
    protected $fillable = [
    'nama_desa',
    'nama_kepala_desa',
    'nama_ketua_bpd',
    'foto_ketua_bpd',
    'lembaga_kemasyarakatan',
    'kecamatan',
    'kabupaten',
    'provinsi',
    'kode_pos',
    'telepon',
    'email',
    'luas_wilayah_km2',
    'maps_embed_url',
    'alamat_kantor',
    'sambutan_kepala_desa',
    'visi',
    'misi',
    'sejarah',
    'foto_kepala_desa',
    'video_kepala_desa',
    'logo',
];

    public static function current(): self
    {
        return static::first() ?? static::create(['nama_desa' => 'Desa Mekarnangka']);
    }
}
