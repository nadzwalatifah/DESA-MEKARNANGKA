<?php

namespace App\Http\Controllers;

use App\Models\Gallery;
use App\Models\Setting;

class GalleryController extends Controller
{
    public function index()
    {
        $setting = Setting::current();
        $galeri = Gallery::latest()->paginate(12);

        return view('galeri.index', compact('setting', 'galeri'));
    }
}
