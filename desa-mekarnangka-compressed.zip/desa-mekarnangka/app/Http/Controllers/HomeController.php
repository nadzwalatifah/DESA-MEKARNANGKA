<?php

namespace App\Http\Controllers;

use App\Models\Article;
use App\Models\Gallery;
use App\Models\Layanan;
use App\Models\Official;
use App\Models\PopulationStat;
use App\Models\Setting;

class HomeController extends Controller
{
    public function index()
    {
        $setting = Setting::current();
        $artikelTerbaru = Article::published()->take(3)->get();
        $galeri = Gallery::latest()->take(6)->get();
        $statistik = PopulationStat::where('dusun', 'Total')
            ->orderByDesc('tahun')
            ->first();

        return view('home', compact('setting', 'artikelTerbaru', 'galeri', 'statistik'));
    }

    public function layanan()
    {
        $setting = Setting::current();
        $layanan = Layanan::aktif()->get();

        return view('layanan', compact('setting', 'layanan'));
    }

    public function struktur()
    {
        $setting = Setting::current();
        $pejabat = Official::urut()->get();

        return view('struktur', compact('setting', 'pejabat'));
    }

    public function statistik()
    {
        $setting = Setting::current();
        $stats = PopulationStat::orderByDesc('tahun')->orderBy('dusun')->get();

        return view('statistik', compact('setting', 'stats'));
    }

    public function kontak()
    {
        $setting = Setting::current();

        return view('kontak', compact('setting'));
    }
}
