<?php

namespace App\Http\Controllers;

use App\Models\Article;
use App\Models\Setting;

class ArticleController extends Controller
{
    public function index()
    {
        $setting = Setting::current();
        $artikel = Article::published()->paginate(9);

        return view('artikel.index', compact('setting', 'artikel'));
    }

    public function show(Article $article)
    {
        abort_unless($article->is_published, 404);

        $article->increment('dilihat');
        $setting = Setting::current();
        $lainnya = Article::published()->where('id', '!=', $article->id)->take(3)->get();

        return view('artikel.show', compact('setting', 'article', 'lainnya'));
    }
}
