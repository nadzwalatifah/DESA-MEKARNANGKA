<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Article;
use App\Models\Gallery;
use App\Models\Official;

class DashboardController extends Controller
{
    public function index()
    {
        $totalArtikel = Article::count();
        $totalGaleri = Gallery::count();
        $totalPejabat = Official::count();

        return view('admin.dashboard', compact('totalArtikel', 'totalGaleri', 'totalPejabat'));
    }
}
