<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\PopulationStat;
use Illuminate\Http\Request;

class PopulationStatController extends Controller
{
    public function index()
    {
        $stats = PopulationStat::orderByDesc('tahun')->orderBy('dusun')->get();

        return view('admin.population-stats.index', compact('stats'));
    }

    public function create()
    {
        return view('admin.population-stats.create');
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'dusun' => 'required|string|max:255',
            'tahun' => 'required|digits:4|integer',
            'jumlah_kk' => 'nullable|integer|min:0',
            'laki_laki' => 'nullable|integer|min:0',
            'perempuan' => 'nullable|integer|min:0',
            'usia_0_15' => 'nullable|integer|min:0',
            'usia_16_55' => 'nullable|integer|min:0',
            'usia_diatas_55' => 'nullable|integer|min:0',
        ]);

        PopulationStat::create($data);

        return redirect()->route('admin.population-stats.index')->with('status', 'Data statistik berhasil ditambahkan.');
    }

    public function edit(PopulationStat $populationStat)
    {
        return view('admin.population-stats.edit', compact('populationStat'));
    }

    public function update(Request $request, PopulationStat $populationStat)
    {
        $data = $request->validate([
            'dusun' => 'required|string|max:255',
            'tahun' => 'required|digits:4|integer',
            'jumlah_kk' => 'nullable|integer|min:0',
            'laki_laki' => 'nullable|integer|min:0',
            'perempuan' => 'nullable|integer|min:0',
            'usia_0_15' => 'nullable|integer|min:0',
            'usia_16_55' => 'nullable|integer|min:0',
            'usia_diatas_55' => 'nullable|integer|min:0',
        ]);

        $populationStat->update($data);

        return redirect()->route('admin.population-stats.index')->with('status', 'Data statistik berhasil diperbarui.');
    }

    public function destroy(PopulationStat $populationStat)
    {
        $populationStat->delete();

        return back()->with('status', 'Data statistik berhasil dihapus.');
    }
}
