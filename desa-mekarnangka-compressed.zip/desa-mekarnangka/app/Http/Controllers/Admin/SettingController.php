<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class SettingController extends Controller
{
    /**
     * Tampilkan form pengaturan desa.
     */
    public function edit()
    {
        $setting = Setting::current();

        return view('admin.settings.edit', compact('setting'));
    }

    /**
     * Simpan perubahan pengaturan desa.
     */
    public function update(Request $request)
    {
        $setting = Setting::current();

        // Bersihkan & normalisasi URL embed Google Maps sebelum divalidasi.
        // Ini menangani beberapa kasus umum saat user copy-paste:
        // - Paste seluruh tag <iframe src="...">...</iframe> -> ambil src="..." saja
        // - Link diawali http:// (bukan https://) -> dibetulkan otomatis jadi https://
        // - Ada spasi/newline/karakter tak terlihat ikut ke-copy -> dibuang
        // - Tanpa "www." (mis. https://maps.google.com/maps/embed?pb=...) -> ditambahkan
        if ($request->filled('maps_embed_url')) {
            $raw = trim($request->input('maps_embed_url'));

            // Kalau yang di-paste adalah seluruh tag <iframe ...>, ambil src="..."-nya saja.
            if (preg_match('/src=["\']([^"\']+)["\']/i', $raw, $m)) {
                $raw = $m[1];
            }

            // Buang whitespace tak terlihat (spasi, tab, newline, non-breaking space, dsb).
            $raw = preg_replace('/[\x{00A0}\x{200B}\s]+/u', '', $raw);

            $raw = trim($raw, "\"' \t\n\r\0\x0B");
            $raw = html_entity_decode($raw, ENT_QUOTES);

            // Betulkan skema http:// -> https://
            if (str_starts_with($raw, 'http://')) {
                $raw = 'https://' . substr($raw, 7);
            }

            // Tambahkan https:// kalau user cuma paste tanpa skema sama sekali.
            if ($raw !== '' && !preg_match('#^https?://#i', $raw)) {
                $raw = 'https://' . $raw;
            }

            // Tambahkan www. kalau linknya maps.google.com tanpa www.
            $raw = preg_replace('#^https://maps\.google\.com/#i', 'https://www.google.com/', $raw);

            $request->merge(['maps_embed_url' => $raw]);
        }

        $validated = $request->validate([
            'nama_desa' => ['required', 'string', 'max:255'],
            'nama_kepala_desa' => ['nullable', 'string', 'max:255'],
            'nama_ketua_bpd' => ['nullable', 'string', 'max:255'],
            'foto_ketua_bpd' => ['nullable', 'image', 'max:2048'],
            'lembaga_kemasyarakatan' => ['nullable', 'string'],
            'kecamatan' => ['nullable', 'string', 'max:255'],
            'kabupaten' => ['nullable', 'string', 'max:255'],
            'provinsi' => ['nullable', 'string', 'max:255'],
            'kode_pos' => ['nullable', 'string', 'max:10'],
            'telepon' => ['nullable', 'string', 'max:30'],
            'email' => ['nullable', 'email', 'max:255'],
            'luas_wilayah_km2' => ['nullable', 'numeric'],
            'maps_embed_url' => [
                'nullable',
                'string',
                'regex:/^https:\/\/www\.google\.com\/maps\/embed\?pb=/',
            ],
            'alamat_kantor' => ['nullable', 'string'],
            'sambutan_kepala_desa' => ['nullable', 'string'],
            'visi' => ['nullable', 'string'],
            'misi' => ['nullable', 'string'],
            'sejarah' => ['nullable', 'string'],
            'foto_kepala_desa' => ['nullable', 'image', 'max:2048'],
            'video_kepala_desa' => ['nullable', 'mimes:mp4,webm,mov,quicktime', 'max:51200'],
            'logo' => ['nullable', 'image', 'max:2048'],
        ], [
            'maps_embed_url.regex' => 'URL harus berupa link EMBED dari Google Maps (Bagikan → Sematkan peta), bukan link share/lokasi biasa. Formatnya diawali dengan https://www.google.com/maps/embed?pb=...',
        ]);

        $data = $validated;

        if ($request->hasFile('foto_kepala_desa')) {
            if ($setting->foto_kepala_desa) {
                Storage::disk('public')->delete($setting->foto_kepala_desa);
            }
            $data['foto_kepala_desa'] = $request->file('foto_kepala_desa')->store('setting', 'public');
        } else {
            unset($data['foto_kepala_desa']);
        }

        if ($request->hasFile('video_kepala_desa')) {
            if ($setting->video_kepala_desa) {
                Storage::disk('public')->delete($setting->video_kepala_desa);
            }
            $data['video_kepala_desa'] = $request->file('video_kepala_desa')->store('setting', 'public');
        } else {
            unset($data['video_kepala_desa']);
        }

        if ($request->hasFile('foto_ketua_bpd')) {
            if ($setting->foto_ketua_bpd) {
                Storage::disk('public')->delete($setting->foto_ketua_bpd);
            }
            $data['foto_ketua_bpd'] = $request->file('foto_ketua_bpd')->store('setting', 'public');
        } else {
            unset($data['foto_ketua_bpd']);
        }

        if ($request->hasFile('logo')) {
            if ($setting->logo) {
                Storage::disk('public')->delete($setting->logo);
            }
            $data['logo'] = $request->file('logo')->store('setting', 'public');
        } else {
            unset($data['logo']);
        }

        $setting->update($data);

        return redirect()->route('admin.settings.edit')->with('status', 'Profil desa berhasil diperbarui.');
    }
}