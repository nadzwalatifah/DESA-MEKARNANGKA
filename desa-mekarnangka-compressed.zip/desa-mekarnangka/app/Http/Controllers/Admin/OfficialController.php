<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Official;
use Illuminate\Http\Request;

class OfficialController extends Controller
{
    public function index()
    {
        $pejabat = Official::urut()->get();

        return view('admin.officials.index', compact('pejabat'));
    }

    public function create()
    {
        return view('admin.officials.create');
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'nama' => 'required|string|max:255',
            'jabatan' => 'required|string|max:255',
            'deskripsi' => 'nullable|string',
            'urutan' => 'nullable|integer|min:0',
            'foto' => 'nullable|image|max:2048',
        ]);

        if ($request->hasFile('foto')) {
            $data['foto'] = $request->file('foto')->store('pejabat', 'public');
        }

        $data['urutan'] = $data['urutan'] ?? 0;

        Official::create($data);

        return redirect()->route('admin.officials.index')->with('status', 'Perangkat desa berhasil ditambahkan.');
    }

    public function edit(Official $official)
    {
        return view('admin.officials.edit', compact('official'));
    }

    public function update(Request $request, Official $official)
    {
        $data = $request->validate([
            'nama' => 'required|string|max:255',
            'jabatan' => 'required|string|max:255',
            'deskripsi' => 'nullable|string',
            'urutan' => 'nullable|integer|min:0',
            'foto' => 'nullable|image|max:2048',
        ]);

        if ($request->hasFile('foto')) {
            $data['foto'] = $request->file('foto')->store('pejabat', 'public');
        }

        $data['urutan'] = $data['urutan'] ?? 0;

        $official->update($data);

        return redirect()->route('admin.officials.index')->with('status', 'Perangkat desa berhasil diperbarui.');
    }

    public function destroy(Official $official)
    {
        $official->delete();

        return back()->with('status', 'Perangkat desa berhasil dihapus.');
    }
}
