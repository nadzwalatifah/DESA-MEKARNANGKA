<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Layanan;
use Illuminate\Http\Request;

class LayananController extends Controller
{
    public function index()
    {
        $layanan = Layanan::orderBy('urutan')->orderBy('id')->paginate(15);

        return view('admin.layanan.index', compact('layanan'));
    }

    public function create()
    {
        return view('admin.layanan.create');
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'judul' => 'required|string|max:255',
            'deskripsi_singkat' => 'required|string|max:500',
            'deskripsi_lengkap' => 'nullable|string',
            'urutan' => 'nullable|integer|min:0',
            'is_aktif' => 'nullable|boolean',
            'foto' => 'nullable|image|max:2048',
            'maps_embed_url' => 'nullable|string',
            'nomor_telepon' => 'nullable|string|max:30',
        ]);

        if ($request->hasFile('foto')) {
            $data['foto'] = $request->file('foto')->store('layanan', 'public');
        }

        $data['urutan'] = $data['urutan'] ?? 0;
        $data['is_aktif'] = $request->boolean('is_aktif');

        Layanan::create($data);

        return redirect()->route('admin.layanan.index')->with('status', 'Layanan berhasil ditambahkan.');
    }

    public function edit(Layanan $layanan)
    {
        return view('admin.layanan.edit', compact('layanan'));
    }

    public function update(Request $request, Layanan $layanan)
    {
        $data = $request->validate([
            'judul' => 'required|string|max:255',
            'deskripsi_singkat' => 'required|string|max:500',
            'deskripsi_lengkap' => 'nullable|string',
            'urutan' => 'nullable|integer|min:0',
            'is_aktif' => 'nullable|boolean',
            'foto' => 'nullable|image|max:2048',
            'maps_embed_url' => 'nullable|string',
            'nomor_telepon' => 'nullable|string|max:30',
        ]);

        if ($request->hasFile('foto')) {
            $data['foto'] = $request->file('foto')->store('layanan', 'public');
        }

        $data['urutan'] = $data['urutan'] ?? 0;
        $data['is_aktif'] = $request->boolean('is_aktif');

        $layanan->update($data);

        return redirect()->route('admin.layanan.index')->with('status', 'Layanan berhasil diperbarui.');
    }

    public function destroy(Layanan $layanan)
    {
        $layanan->delete();

        return back()->with('status', 'Layanan berhasil dihapus.');
    }
}
