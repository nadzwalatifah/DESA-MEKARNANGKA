<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('population_stats', function (Blueprint $table) {
            $table->id();
            $table->string('dusun'); // nama dusun/RW, atau "Total"
            $table->year('tahun');
            $table->unsignedInteger('jumlah_kk')->default(0);
            $table->unsignedInteger('laki_laki')->default(0);
            $table->unsignedInteger('perempuan')->default(0);
            $table->unsignedInteger('usia_0_15')->default(0);
            $table->unsignedInteger('usia_16_55')->default(0);
            $table->unsignedInteger('usia_diatas_55')->default(0);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('population_stats');
    }
};
