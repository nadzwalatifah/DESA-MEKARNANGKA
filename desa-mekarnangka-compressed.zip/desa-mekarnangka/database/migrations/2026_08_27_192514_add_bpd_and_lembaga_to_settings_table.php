<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('settings', function (Blueprint $table) {
            $table->string('nama_ketua_bpd')->nullable()->after('nama_kepala_desa');
            $table->string('foto_ketua_bpd')->nullable()->after('nama_ketua_bpd');
            // Daftar lembaga kemasyarakatan, satu baris satu lembaga (LPMD, TP PKK, Karang Taruna, dll).
            $table->text('lembaga_kemasyarakatan')->nullable()->after('foto_ketua_bpd');
        });
    }

    public function down(): void
    {
        Schema::table('settings', function (Blueprint $table) {
            $table->dropColumn(['nama_ketua_bpd', 'foto_ketua_bpd', 'lembaga_kemasyarakatan']);
        });
    }
};
