<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('layanans', function (Blueprint $table) {
            $table->string('foto')->nullable()->after('deskripsi_lengkap');
            $table->text('maps_embed_url')->nullable()->after('foto');
            $table->string('nomor_telepon')->nullable()->after('maps_embed_url');
        });
    }

    public function down(): void
    {
        Schema::table('layanans', function (Blueprint $table) {
            $table->dropColumn(['foto', 'maps_embed_url', 'nomor_telepon']);
        });
    }
};
