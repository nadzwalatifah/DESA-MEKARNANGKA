<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('galleries', function (Blueprint $table) {
            if (Schema::hasColumn('galleries', 'gambar') && !Schema::hasColumn('galleries', 'foto')) {
                $table->renameColumn('gambar', 'foto');
            }

            if (Schema::hasColumn('galleries', 'keterangan') && !Schema::hasColumn('galleries', 'deskripsi')) {
                $table->renameColumn('keterangan', 'deskripsi');
            }

            if (!Schema::hasColumn('galleries', 'urutan')) {
                $table->integer('urutan')->default(0)->after('deskripsi');
            }
        });
    }

    public function down(): void
    {
        Schema::table('galleries', function (Blueprint $table) {
            if (Schema::hasColumn('galleries', 'urutan')) {
                $table->dropColumn('urutan');
            }

            if (Schema::hasColumn('galleries', 'deskripsi')) {
                $table->renameColumn('deskripsi', 'keterangan');
            }

            if (Schema::hasColumn('galleries', 'foto')) {
                $table->renameColumn('foto', 'gambar');
            }
        });
    }
};