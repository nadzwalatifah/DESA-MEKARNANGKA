<?php

namespace Database\Seeders;

use App\Models\Article;
use App\Models\Official;
use App\Models\PopulationStat;
use App\Models\Setting;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class DesaMekarnangkaSeeder extends Seeder
{
    public function run(): void
    {
        Setting::query()->delete();
        Setting::create([
            'nama_desa' => 'Desa Mekarnangka',
            'kecamatan' => 'Kecamatan Contoh', // sesuaikan
            'kabupaten' => 'Kabupaten Contoh', // sesuaikan
            'provinsi' => 'Provinsi Contoh',   // sesuaikan
            'kode_pos' => '00000',
            'alamat_kantor' => 'Jl. Raya Mekarnangka No. 1, Desa Mekarnangka',
            'telepon' => '(0000) 000000',
            'email' => 'desamekarnangka@example.go.id',
            'nama_kepala_desa' => 'Kepala Desa Mekarnangka',
            'sambutan_kepala_desa' => 'Selamat datang di website resmi Desa Mekarnangka. Website ini kami hadirkan sebagai media informasi dan transparansi kepada seluruh warga serta masyarakat umum mengenai profil, kegiatan, dan pelayanan yang ada di desa kami. Semoga bermanfaat.',
            'visi' => 'Terwujudnya Desa Mekarnangka yang mandiri, sejahtera, dan berbudaya menuju masyarakat yang maju dan berkeadilan.',
            'misi' => "1. Meningkatkan kualitas pelayanan publik yang transparan dan akuntabel.\n2. Mengembangkan potensi ekonomi lokal dan UMKM desa.\n3. Meningkatkan infrastruktur desa yang merata.\n4. Melestarikan budaya dan gotong royong masyarakat.",
            'sejarah' => 'Desa Mekarnangka merupakan salah satu desa yang terus berkembang dengan mengedepankan semangat gotong royong warganya. (Isi sejarah lengkap desa dapat disesuaikan melalui panel admin.)',
            'luas_wilayah_km2' => 12.5,
            'maps_embed_url' => null,
        ]);

        Official::query()->delete();
        $struktur = [
            ['nama' => '(Nama Kepala Desa)', 'jabatan' => 'Kepala Desa', 'urutan' => 1],
            ['nama' => '(Nama Sekretaris Desa)', 'jabatan' => 'Sekretaris Desa', 'urutan' => 2],
            ['nama' => '(Nama Kaur Keuangan)', 'jabatan' => 'Kaur Keuangan', 'urutan' => 3],
            ['nama' => '(Nama Kaur Umum)', 'jabatan' => 'Kaur Umum & Perencanaan', 'urutan' => 4],
            ['nama' => '(Nama Kasi Pemerintahan)', 'jabatan' => 'Kasi Pemerintahan', 'urutan' => 5],
            ['nama' => '(Nama Kasi Kesejahteraan)', 'jabatan' => 'Kasi Kesejahteraan', 'urutan' => 6],
            ['nama' => '(Nama Kadus 1)', 'jabatan' => 'Kepala Dusun 1', 'urutan' => 7],
            ['nama' => '(Nama Kadus 2)', 'jabatan' => 'Kepala Dusun 2', 'urutan' => 8],
        ];
        foreach ($struktur as $s) {
            Official::create($s);
        }

        PopulationStat::query()->delete();
        PopulationStat::create([
            'dusun' => 'Dusun 1',
            'tahun' => now()->year,
            'jumlah_kk' => 320,
            'laki_laki' => 610,
            'perempuan' => 590,
            'usia_0_15' => 350,
            'usia_16_55' => 700,
            'usia_diatas_55' => 150,
        ]);
        PopulationStat::create([
            'dusun' => 'Dusun 2',
            'tahun' => now()->year,
            'jumlah_kk' => 280,
            'laki_laki' => 520,
            'perempuan' => 505,
            'usia_0_15' => 300,
            'usia_16_55' => 600,
            'usia_diatas_55' => 125,
        ]);
        PopulationStat::create([
            'dusun' => 'Total',
            'tahun' => now()->year,
            'jumlah_kk' => 600,
            'laki_laki' => 1130,
            'perempuan' => 1095,
            'usia_0_15' => 650,
            'usia_16_55' => 1300,
            'usia_diatas_55' => 275,
        ]);

        Article::query()->delete();
        $artikel = [
            [
                'judul' => 'Musyawarah Desa Penyusunan RKP Desa Mekarnangka',
                'kategori' => 'Kegiatan',
                'ringkasan' => 'Pemerintah Desa Mekarnangka menggelar musyawarah desa untuk menyusun Rencana Kerja Pemerintah (RKP) Desa tahun mendatang.',
                'konten' => "Pemerintah Desa Mekarnangka bersama Badan Permusyawaratan Desa (BPD) dan tokoh masyarakat menggelar musyawarah desa membahas penyusunan RKP Desa. Kegiatan ini bertujuan menampung aspirasi warga terkait pembangunan infrastruktur, pemberdayaan ekonomi, dan program sosial di tahun mendatang.\n\nSeluruh elemen masyarakat diharapkan turut berpartisipasi aktif demi terwujudnya pembangunan desa yang tepat sasaran.",
            ],
            [
                'judul' => 'Pengumuman Jadwal Pelayanan Administrasi Kependudukan',
                'kategori' => 'Pengumuman',
                'ringkasan' => 'Kantor Desa Mekarnangka mengumumkan jadwal pelayanan administrasi kependudukan bagi warga.',
                'konten' => "Kepada seluruh warga Desa Mekarnangka, pelayanan administrasi kependudukan (KTP, KK, Surat Pengantar, dll) dilayani setiap hari Senin-Jumat pukul 08.00-14.00 WIB di Kantor Desa.\n\nWarga diharapkan membawa dokumen pendukung yang lengkap agar proses pelayanan berjalan lancar.",
            ],
            [
                'judul' => 'Gotong Royong Bersih Desa Mekarnangka',
                'kategori' => 'Kegiatan',
                'ringkasan' => 'Warga Desa Mekarnangka bersama perangkat desa melaksanakan kegiatan gotong royong membersihkan lingkungan.',
                'konten' => "Dalam rangka menjaga kebersihan dan kesehatan lingkungan, warga Desa Mekarnangka melaksanakan kegiatan gotong royong bersih desa yang meliputi pembersihan saluran air, jalan lingkungan, dan fasilitas umum.\n\nKegiatan ini rutin dilaksanakan sebagai wujud semangat kebersamaan warga desa.",
            ],
        ];
        foreach ($artikel as $a) {
            Article::create($a + [
                'slug' => Str::slug($a['judul']).'-'.Str::random(5),
                'is_published' => true,
                'published_at' => now(),
            ]);
        }
    }
}
